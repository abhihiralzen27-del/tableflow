'use strict';
const HOME = { admin: '/admin', waiter: '/floor', kitchen: '/kitchen' };
(async () => {
  try { const me = await api('/api/auth/me'); location.replace(HOME[me.user.role]); } catch { /* not signed in */ }
})();
$('#f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#go'); btn.disabled = true; $('#err').textContent = '';
  try {
    const r = await api('/api/auth/login', { method: 'POST', body: { email: $('#email').value, password: $('#pw').value } });
    location.href = HOME[r.user.role];
  } catch (err) { $('#err').textContent = err.message; btn.disabled = false; }
});
