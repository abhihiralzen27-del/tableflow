'use strict';
(() => {
  const S = { tab: localStorage.getItem('admintab') || 'overview', me: null, menu: null, tables: null, users: null, settings: null, ov: null };
  const root = $('#app');
  const TABS = [['overview', 'Overview'], ['menu', 'Menu'], ['promos', 'Deals & rewards'], ['tables', 'Tables & QR'], ['staff', 'Staff'], ['settings', 'Settings']];
  const DIETN = { veg: 'Vegetarian', vegan: 'Vegan', nonveg: 'Non-veg', egg: 'Contains egg' };
  const toCents = (v) => Math.round(parseFloat(v) * 100);
  const toMajor = (c) => (c / 100).toFixed(2);
  const D = new Date();

  async function boot() {
    try { S.me = (await api('/api/auth/me')).user; } catch { location.href = '/login'; return; }
    if (S.me.role !== 'admin') { location.href = S.me.role === 'kitchen' ? '/kitchen' : '/floor'; return; }
    const s = await api('/api/admin/settings'); S.settings = s; setMoney(s.settings.locale, s.settings.currency);
    await show(S.tab);
  }
  async function show(tab) {
    S.tab = tab; localStorage.setItem('admintab', tab);
    shell(h('div', { class: 'spinner', role: 'status' }));
    try {
      if (tab === 'overview') S.ov = await api('/api/admin/overview');
      if (tab === 'menu' || tab === 'promos') S.menu = await api('/api/admin/menu');
      if (tab === 'tables') S.tables = await api('/api/admin/tables');
      if (tab === 'staff') S.users = (await api('/api/admin/users')).users;
      if (tab === 'settings') S.settings = await api('/api/admin/settings');
      shell(({ overview, menu, promos, tables, staff, settings })[tab]());
    } catch (e) { if (e.status === 401) location.href = '/login'; else shell(h('p', { class: 'err' }, e.message)); }
  }
  const reload = () => show(S.tab);
  function shell(content) {
    root.replaceChildren(
      h('div', { class: 'stafftop' }, h('h1', null, '⚙️ Admin'), h('div', { class: 'grow' }), h('a', { class: 'btn sm', href: '/floor' }, 'Floor'), h('a', { class: 'btn sm', href: '/kitchen' }, 'Kitchen'),
        h('button', { class: 'btn sm', onclick: async () => { await api('/api/auth/logout', { method: 'POST' }); location.href = '/login'; } }, 'Sign out')),
      h('div', { class: 'tabs', role: 'tablist' }, TABS.map(([k, l]) => h('button', { class: 'tab', role: 'tab', 'aria-selected': S.tab === k, onclick: () => show(k) }, l))),
      h('div', { class: 'layout', style: { maxWidth: '1100px' } }, content));
  }
  const field = (label, input, id) => h('div', null, h('label', { for: id }, label), input);
  const save = (fn, btn) => guard(async () => { await fn(); }, btn);

  // ------------------------------------------------------------ overview
  function overview() {
    const o = S.ov, p = o.payments;
    return h('div', { class: 'stack' },
      h('div', { class: 'fields' },
        stat('Sales today', money(o.sales.amount), `${o.sales.n} payments`), stat('Tips today', money(o.sales.tips), ''), stat('Average rating', o.rating.n ? `${o.rating.avg} ★` : '—', `${o.rating.n} reviews`)),
      h('div', { class: 'card' }, h('h3', null, 'Setup checklist'), h('ul', { class: 'small' },
        check(p.online_enabled, 'Online card / Apple Pay / Google Pay', p.provider === 'mock' ? 'Demo mode: payments are simulated.' : p.mock_blocked_in_production ? 'Mock payments are blocked in production. Configure Stripe.' : 'Not configured. Guests can still pay cash or by bank transfer.'),
        check(p.email_configured, 'Receipt emails', 'Not configured. Receipts are still available by link.'),
        check(!/localhost|127\.0\.0\.1/.test(S.settings.base_url_detected), 'Public website address', `Currently ${S.settings.base_url_detected}. QR codes use this address — set BASE_URL or the public URL in Settings.`))),
      h('div', { class: 'card' }, h('h3', null, 'Payments today by method'), o.byMethod.length ? h('table', { class: 'data' }, o.byMethod.map((m) => h('tr', null, h('td', null, m.method.replace('_', ' ')), h('td', { class: 'r' }, money(m.total))))) : h('p', { class: 'muted' }, 'No payments yet today.')),
      h('div', { class: 'card' }, h('h3', null, 'Top dishes (last 7 days)'), o.top.length ? h('table', { class: 'data' }, o.top.map((t) => h('tr', null, h('td', null, t.name), h('td', { class: 'r' }, t.qty)))) : h('p', { class: 'muted' }, 'No orders yet.')),
      h('div', { class: 'card' }, h('h3', null, 'Latest reviews'), o.reviews.length ? h('div', { class: 'list' }, o.reviews.map((r) => h('div', null, h('b', null, '⭐'.repeat(r.rating)), h('span', { class: 'muted small' }, ` Table ${r.label || '?'} · ${new Date(r.created_at).toLocaleString()}`), r.comment ? h('div', null, r.comment) : null))) : h('p', { class: 'muted' }, 'No reviews yet.')),
      h('div', { class: 'card' }, h('h3', null, 'Enquiries from the website'), o.leads.length ? h('div', { class: 'list' }, o.leads.map((l) => h('div', null, h('b', null, l.name), ' · ', h('a', { href: 'mailto:' + l.email }, l.email), l.restaurant ? ` · ${l.restaurant}` : '', h('div', { class: 'small muted' }, new Date(l.created_at).toLocaleString()), l.message ? h('div', null, l.message) : null))) : h('p', { class: 'muted' }, 'None yet.')),
      h('div', { class: 'card' }, h('h3', null, 'Recent admin activity'), o.log.length ? h('table', { class: 'data' }, o.log.map((l) => h('tr', null, h('td', null, new Date(l.created_at).toLocaleString()), h('td', null, l.name || '—'), h('td', null, l.action + ' ' + l.detail)))) : h('p', { class: 'muted' }, 'Nothing yet.')));
  }
  const stat = (l, v, s) => h('div', { class: 'card' }, h('div', { class: 'muted small' }, l), h('div', { class: 'stat' }, v), h('div', { class: 'small muted' }, s));
  const check = (ok, t, hint) => h('li', null, ok ? '✅ ' : '⚠️ ', h('b', null, t), ok ? '' : ' — ' + hint);

  // ------------------------------------------------------------ menu
  function menu() {
    const m = S.menu;
    return h('div', { class: 'stack' }, h('div', { class: 'row wrap' }, h('button', { class: 'btn primary', onclick: () => itemForm(null) }, '+ Add dish'), h('button', { class: 'btn', onclick: catForm }, '+ Add category')),
      m.categories.map((c) => h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h3', { style: { margin: 0 } }, c.name), h('div', { class: 'row' }, h('button', { class: 'btn sm', onclick: () => catForm(c) }, 'Rename'), h('button', { class: 'btn sm danger', onclick: () => confirm(`Delete "${c.name}" and all its dishes?`) && save(async () => { await api('/api/admin/categories/' + c.id, { method: 'DELETE' }); reload(); }) }, 'Delete'))),
        h('div', { class: 'list' }, m.items.filter((i) => i.category_id === c.id).map((i) => h('div', { class: 'row between' }, h('div', null, `${i.emoji} `, h('b', null, i.name), ' ', h('span', { class: 'muted' }, money(i.price_cents)), !i.available ? h('span', { class: 'badge bad', style: { marginLeft: '.4rem' } }, 'hidden') : null, h('div', { class: 'small muted' }, `${DIETN[i.diet]} · ${i.station} · ${i.allergens.join(', ') || 'no allergens'}`)),
          h('div', { class: 'row' }, h('button', { class: 'btn sm', onclick: () => save(async () => { await api('/api/admin/items/' + i.id, { method: 'PUT', body: { ...i, available: !i.available } }); reload(); }) }, i.available ? 'Hide' : 'Show'), h('button', { class: 'btn sm', onclick: () => itemForm(i) }, 'Edit'))))))),
      !m.categories.length ? h('div', { class: 'empty' }, 'Start by adding a category such as "Starters".') : null);
  }
  function catForm(c) {
    const sh = sheet('Category', h('div', { class: 'stack' }, h('h2', null, c?.id ? 'Rename category' : 'New category'), field('Name', h('input', { id: 'cn', type: 'text', maxlength: 60, value: c?.name || '' }), 'cn'),
      h('button', { class: 'btn primary block', onclick: (e) => save(async () => { const b = { name: $('#cn').value, sort: c?.sort || 0 }; c?.id ? await api('/api/admin/categories/' + c.id, { method: 'PUT', body: b }) : await api('/api/admin/categories', { method: 'POST', body: b }); sh.close(); reload(); }, e.currentTarget) }, 'Save')));
  }
  function itemForm(it) {
    const m = S.menu; const sizes = (it?.sizes || []).map((s) => ({ ...s })); const al = new Set(it?.allergens || []);
    const sizeBox = h('div');
    const drawSizes = () => sizeBox.replaceChildren(sizes.map((s, i) => h('div', { class: 'row', style: { marginTop: '.4rem' } }, h('input', { type: 'text', placeholder: 'Size name', value: s.name, 'aria-label': 'Size name', oninput: (e) => { s.name = e.target.value; } }), h('input', { type: 'number', step: '0.01', placeholder: '± price', value: toMajor(s.delta_cents), 'aria-label': 'Price change', oninput: (e) => { s.delta_cents = toCents(e.target.value) || 0; } }), h('button', { class: 'btn sm danger', 'aria-label': 'Remove size', onclick: () => { sizes.splice(i, 1); drawSizes(); } }, '✕'))));
    drawSizes();
    const sh = sheet('Dish', h('div', { class: 'stack' }, h('h2', null, it ? 'Edit dish' : 'New dish'),
      h('div', { class: 'fields' }, field('Name', h('input', { id: 'in', type: 'text', maxlength: 80, value: it?.name || '' }), 'in'), field('Emoji', h('input', { id: 'ie', type: 'text', maxlength: 8, value: it?.emoji || '🍽️' }), 'ie')),
      field('Description', h('textarea', { id: 'id', maxlength: 300 }, it?.description || ''), 'id'),
      h('div', { class: 'fields' }, field('Category', h('select', { id: 'ic' }, m.categories.map((c) => h('option', { value: c.id, selected: it?.category_id === c.id }, c.name))), 'ic'),
        field(`Price (${S.settings.settings.currency})`, h('input', { id: 'ip', type: 'number', step: '0.01', min: 0, value: it ? toMajor(it.price_cents) : '' }), 'ip'),
        field('Diet', h('select', { id: 'idt' }, m.diets.map((d) => h('option', { value: d, selected: it?.diet === d }, DIETN[d]))), 'idt'),
        field('Spice level', h('select', { id: 'is' }, ['None', 'Mild', 'Medium', 'Hot'].map((l, i) => h('option', { value: i, selected: (it?.spice || 0) === i }, l))), 'is'),
        field('Kitchen station', h('select', { id: 'ist' }, m.stations.map((s) => h('option', { value: s, selected: it?.station === s }, s))), 'ist'),
        field('Prep time (min)', h('input', { id: 'ipm', type: 'number', min: 1, max: 180, value: it?.prep_minutes ?? 10 }), 'ipm')),
      h('div', null, h('label', null, 'Allergens'), h('div', { class: 'chips', style: { flexWrap: 'wrap' } }, m.allergens.map((a) => h('button', { type: 'button', class: 'chip', 'aria-pressed': al.has(a), onclick: (e) => { al.has(a) ? al.delete(a) : al.add(a); e.currentTarget.setAttribute('aria-pressed', al.has(a)); } }, a)))),
      h('div', null, h('label', null, 'Sizes (optional, e.g. Half / Full)'), sizeBox, h('button', { type: 'button', class: 'btn sm', style: { marginTop: '.5rem' }, onclick: () => { sizes.push({ name: '', delta_cents: 0 }); drawSizes(); } }, '+ Add size'), h('p', { class: 'small muted' }, 'Price change is added to the base price (use a negative number for smaller sizes).')),
      h('div', { class: 'row' }, h('button', { class: 'btn primary grow', onclick: (e) => save(async () => {
        const b = { name: $('#in').value, emoji: $('#ie').value, description: $('#id').value, category_id: Number($('#ic').value), price_cents: toCents($('#ip').value), diet: $('#idt').value, spice: Number($('#is').value), station: $('#ist').value, prep_minutes: Number($('#ipm').value), allergens: [...al], sizes: sizes.filter((s) => s.name.trim()), available: it ? it.available : true };
        if (!Number.isFinite(b.price_cents)) throw new Error('Enter a price');
        it ? await api('/api/admin/items/' + it.id, { method: 'PUT', body: b }) : await api('/api/admin/items', { method: 'POST', body: b });
        sh.close(); reload();
      }, e.currentTarget) }, 'Save dish'), it ? h('button', { class: 'btn danger', onclick: () => confirm('Delete this dish?') && save(async () => { await api('/api/admin/items/' + it.id, { method: 'DELETE' }); sh.close(); reload(); }) }, 'Delete') : null)));
  }

  // ------------------------------------------------------------ deals & rewards
  function promos() {
    const m = S.menu;
    return h('div', { class: 'stack' },
      h('div', { class: 'card stack' }, h('div', { class: 'row between' }, h('h3', { style: { margin: 0 } }, 'Deals shown on the guest menu'), h('button', { class: 'btn sm primary', onclick: () => dealForm(null) }, '+ New deal')),
        m.deals.length ? h('div', { class: 'list' }, m.deals.map((d) => h('div', { class: 'row between' }, h('div', null, h('b', null, d.title), !d.active ? h('span', { class: 'badge bad', style: { marginLeft: '.4rem' } }, 'off') : null, h('div', { class: 'small muted' }, d.description, d.item_id ? ` · ${m.items.find((i) => i.id === d.item_id)?.name}: ${money(d.deal_price_cents)}` : '')), h('div', { class: 'row' }, h('button', { class: 'btn sm', onclick: () => dealForm(d) }, 'Edit'), h('button', { class: 'btn sm danger', onclick: () => confirm('Delete this deal?') && save(async () => { await api('/api/admin/deals/' + d.id, { method: 'DELETE' }); reload(); }) }, 'Delete'))))) : h('p', { class: 'muted' }, 'No deals yet. A deal can simply announce an offer, or set a special price for one dish.')),
      h('div', { class: 'card stack' }, h('h3', { style: { margin: 0 } }, 'Rewards guests can redeem with points'),
        m.rewards.filter((r) => r.active).map((r) => h('div', { class: 'row between' }, h('span', null, `${r.name} · ${r.cost_points} points`), h('button', { class: 'btn sm danger', onclick: () => save(async () => { await api('/api/admin/rewards/' + r.id, { method: 'DELETE' }); reload(); }) }, 'Remove'))),
        h('div', { class: 'row wrap' }, h('input', { id: 'rn', type: 'text', placeholder: 'Reward, e.g. Free dessert', maxlength: 80, 'aria-label': 'Reward name', class: 'grow' }), h('input', { id: 'rp', type: 'number', min: 1, placeholder: 'Points', 'aria-label': 'Points', style: { maxWidth: '110px' } }), h('button', { class: 'btn primary', onclick: (e) => save(async () => { await api('/api/admin/rewards', { method: 'POST', body: { name: $('#rn').value, cost_points: Number($('#rp').value) } }); reload(); }, e.currentTarget) }, 'Add')),
        h('p', { class: 'small muted' }, 'Guests earn points when they pay (rate in Settings), win games and answer quiz questions. Redemptions appear on the waiter screen.')));
  }
  function dealForm(d) {
    const m = S.menu;
    const sh = sheet('Deal', h('div', { class: 'stack' }, h('h2', null, d ? 'Edit deal' : 'New deal'), field('Title', h('input', { id: 'dt', type: 'text', maxlength: 80, value: d?.title || '' }), 'dt'), field('Description', h('input', { id: 'dd', type: 'text', maxlength: 250, value: d?.description || '' }), 'dd'),
      field('Special price for one dish (optional)', h('select', { id: 'di' }, h('option', { value: '' }, '— announcement only —'), m.items.map((i) => h('option', { value: i.id, selected: d?.item_id === i.id }, `${i.name} (${money(i.price_cents)})`))), 'di'),
      field('Deal price', h('input', { id: 'dp', type: 'number', step: '0.01', min: 0, value: d?.deal_price_cents != null ? toMajor(d.deal_price_cents) : '' }), 'dp'),
      h('label', { class: 'opt' }, h('input', { id: 'da', type: 'checkbox', checked: d ? !!d.active : true }), 'Active'),
      h('button', { class: 'btn primary block', onclick: (e) => save(async () => { const item = $('#di').value; const b = { title: $('#dt').value, description: $('#dd').value, item_id: item ? Number(item) : null, deal_price_cents: item && $('#dp').value !== '' ? toCents($('#dp').value) : null, active: $('#da').checked }; d ? await api('/api/admin/deals/' + d.id, { method: 'PUT', body: b }) : await api('/api/admin/deals', { method: 'POST', body: b }); sh.close(); reload(); }, e.currentTarget) }, 'Save deal')));
  }

  // ------------------------------------------------------------ tables & QR
  function tables() {
    const T = S.tables, local = /localhost|127\.0\.0\.1/.test(T.base_url);
    return h('div', { class: 'stack' },
      local ? h('div', { class: 'card', style: { borderColor: 'var(--gold)' } }, h('b', null, '⚠️ QR codes currently point to ' + T.base_url), h('p', { class: 'small', style: { margin: '.3rem 0 0' } }, 'Phones cannot open this address. Set your public website address (BASE_URL, or Settings → Public URL) before printing.')) : null,
      h('div', { class: 'card noprint stack' }, h('h3', { style: { margin: 0 } }, 'Floor layout'), h('p', { class: 'small muted', style: { margin: 0 } }, 'Drag tables to match your restaurant. The waiter screen uses this layout.'), floorEditor(), h('div', { class: 'row wrap' }, h('input', { id: 'tl', type: 'text', maxlength: 12, placeholder: 'New table label, e.g. T9', 'aria-label': 'Table label', style: { maxWidth: '200px' } }), h('input', { id: 'ts', type: 'number', min: 1, max: 30, value: 4, 'aria-label': 'Seats', style: { maxWidth: '90px' } }), h('button', { class: 'btn primary', onclick: (e) => save(async () => { await api('/api/admin/tables', { method: 'POST', body: { label: $('#tl').value, seats: Number($('#ts').value) } }); reload(); }, e.currentTarget) }, '+ Add table'))),
      h('div', { class: 'row between noprint' }, h('h3', { style: { margin: 0 } }, 'QR codes'), h('button', { class: 'btn', onclick: () => window.print() }, '🖨️ Print all')),
      h('div', { class: 'qrbox' }, T.tables.filter((t) => t.active).map((t) => h('div', { class: 'qrcard' }, h('b', null, `Table ${t.label}`), h('img', { src: `/api/admin/tables/${t.id}/qr.svg?v=${t.token.slice(0, 6)}`, alt: `QR code for table ${t.label}`, width: 200, height: 200 }), h('div', { class: 'small muted' }, 'Scan to see the menu & order'),
        h('div', { class: 'row noprint', style: { justifyContent: 'center', marginTop: '.4rem' } }, h('button', { class: 'btn sm', onclick: () => editTable(t) }, 'Edit'), h('button', { class: 'btn sm danger', onclick: () => confirm(`Generate a new QR for ${t.label}? The printed one will stop working.`) && save(async () => { await api(`/api/admin/tables/${t.id}/rotate`, { method: 'POST' }); reload(); }) }, 'New code'))))),
      T.tables.some((t) => !t.active) ? h('p', { class: 'small muted noprint' }, `${T.tables.filter((t) => !t.active).length} table(s) are switched off. Use Edit to switch them back on.`) : null);
  }
  function floorEditor() {
    const box = h('div', { class: 'floor', style: { height: '340px' } });
    for (const t of S.tables.tables.filter((x) => x.active)) {
      const n = h('div', { class: 'tbl free', role: 'button', tabindex: 0, 'aria-label': `Table ${t.label}. Drag, or use arrow keys, to move`, style: { left: t.x + '%', top: t.y + '%', cursor: 'grab', touchAction: 'none' } }, t.label, h('small', null, t.seats + ' seats'));
      const persist = () => guard(() => api('/api/admin/tables/' + t.id, { method: 'PUT', body: { label: t.label, seats: t.seats, x: t.x, y: t.y, active: true } }));
      n.addEventListener('pointerdown', (e) => {
        n.setPointerCapture(e.pointerId); n.style.cursor = 'grabbing';
        const mv = (ev) => { const r = box.getBoundingClientRect(); t.x = Math.min(97, Math.max(3, ((ev.clientX - r.left) / r.width) * 100)); t.y = Math.min(95, Math.max(5, ((ev.clientY - r.top) / r.height) * 100)); n.style.left = t.x + '%'; n.style.top = t.y + '%'; };
        const up = () => { n.removeEventListener('pointermove', mv); n.removeEventListener('pointerup', up); n.style.cursor = 'grab'; t.x = Math.round(t.x * 10) / 10; t.y = Math.round(t.y * 10) / 10; persist(); };
        n.addEventListener('pointermove', mv); n.addEventListener('pointerup', up);
      });
      n.addEventListener('keydown', (e) => { const d = { ArrowLeft: [-2, 0], ArrowRight: [2, 0], ArrowUp: [0, -2], ArrowDown: [0, 2] }[e.key]; if (!d) return; e.preventDefault(); t.x = Math.min(97, Math.max(3, t.x + d[0])); t.y = Math.min(95, Math.max(5, t.y + d[1])); n.style.left = t.x + '%'; n.style.top = t.y + '%'; clearTimeout(n._t); n._t = setTimeout(persist, 500); });
      box.append(n);
    }
    return box;
  }
  function editTable(t) {
    const sh = sheet('Table', h('div', { class: 'stack' }, h('h2', null, `Edit ${t.label}`), field('Label', h('input', { id: 'el', type: 'text', maxlength: 12, value: t.label }), 'el'), field('Seats', h('input', { id: 'es', type: 'number', min: 1, max: 30, value: t.seats }), 'es'),
      h('label', { class: 'opt' }, h('input', { id: 'ea', type: 'checkbox', checked: !!t.active }), 'Table is in use'),
      h('button', { class: 'btn primary block', onclick: (e) => save(async () => { await api('/api/admin/tables/' + t.id, { method: 'PUT', body: { label: $('#el').value, seats: Number($('#es').value), x: t.x, y: t.y, active: $('#ea').checked } }); sh.close(); reload(); }, e.currentTarget) }, 'Save')));
  }

  // ------------------------------------------------------------ staff
  function staff() {
    return h('div', { class: 'stack' }, h('div', { class: 'card' }, h('h3', null, 'Team accounts'), h('table', { class: 'data' }, h('tr', null, h('th', null, 'Name'), h('th', null, 'Email'), h('th', null, 'Role'), h('th', null, '')),
      S.users.map((u) => h('tr', null, h('td', null, u.name), h('td', null, u.email), h('td', null, u.role, !u.active ? h('span', { class: 'badge bad', style: { marginLeft: '.3rem' } }, 'off') : null),
        h('td', { class: 'r' }, h('button', { class: 'btn sm', onclick: () => pwForm(u) }, 'New password'), ' ', u.email !== S.me.email ? h('button', { class: 'btn sm', onclick: () => save(async () => { await api('/api/admin/users/' + u.id, { method: 'PUT', body: { active: !u.active } }); reload(); }) }, u.active ? 'Disable' : 'Enable') : null))))),
      h('div', { class: 'card stack' }, h('h3', { style: { margin: 0 } }, 'Add a team member'), h('div', { class: 'fields' }, field('Name', h('input', { id: 'un', type: 'text', maxlength: 80 }), 'un'), field('Email', h('input', { id: 'ue', type: 'email' }), 'ue'),
        field('Role', h('select', { id: 'ur' }, [['waiter', 'Waiter (floor)'], ['kitchen', 'Kitchen'], ['admin', 'Admin']].map(([v, l]) => h('option', { value: v }, l))), 'ur'), field('Temporary password (10+ characters, letters and numbers)', h('input', { id: 'up', type: 'password', autocomplete: 'new-password' }), 'up')),
        h('button', { class: 'btn primary', onclick: (e) => save(async () => { await api('/api/admin/users', { method: 'POST', body: { name: $('#un').value, email: $('#ue').value, role: $('#ur').value, password: $('#up').value } }); toast('Account created'); reload(); }, e.currentTarget) }, 'Create account')),
      h('div', { class: 'card stack' }, h('h3', { style: { margin: 0 } }, 'Change my password'), h('div', { class: 'fields' }, field('Current password', h('input', { id: 'cp', type: 'password', autocomplete: 'current-password' }), 'cp'), field('New password', h('input', { id: 'np', type: 'password', autocomplete: 'new-password' }), 'np')),
        h('button', { class: 'btn', onclick: (e) => save(async () => { await api('/api/auth/password', { method: 'POST', body: { current: $('#cp').value, next: $('#np').value } }); toast('Password changed'); $('#cp').value = ''; $('#np').value = ''; }, e.currentTarget) }, 'Change password')));
  }
  function pwForm(u) {
    const sh = sheet('Password', h('div', { class: 'stack' }, h('h2', null, `New password for ${u.name}`), field('Password', h('input', { id: 'rp1', type: 'password', autocomplete: 'new-password' }), 'rp1'), h('p', { class: 'small muted' }, 'They will be signed out everywhere.'),
      h('button', { class: 'btn primary block', onclick: (e) => save(async () => { await api('/api/admin/users/' + u.id, { method: 'PUT', body: { active: u.active, password: $('#rp1').value } }); sh.close(); toast('Password updated'); }, e.currentTarget) }, 'Update')));
  }

  // ------------------------------------------------------------ settings
  function settings() {
    const s = S.settings.settings, p = S.settings.payments;
    const inp = (id, label, val, extra = {}) => field(label, h('input', { id, type: 'text', value: val, ...extra }), id);
    return h('div', { class: 'stack' }, h('div', { class: 'card stack' }, h('h3', { style: { margin: 0 } }, 'Restaurant'),
      h('div', { class: 'fields' }, inp('s1', 'Restaurant name', s.restaurant_name, { maxlength: 80 }), inp('s2', 'Currency code (e.g. INR, USD, EUR)', s.currency, { maxlength: 3 }), inp('s3', 'Tax / GST percent added to bills', s.tax_percent, { inputmode: 'numeric' }), inp('s4', 'Tip options, comma separated (%)', s.tip_presets), inp('s5', 'Reward points per 1 currency unit paid', s.points_per_unit, { inputmode: 'numeric' })),
      h('h3', { style: { margin: '1rem 0 0' } }, 'Guest Wi-Fi'), h('div', { class: 'fields' }, inp('s6', 'Wi-Fi network name', s.wifi_ssid, { maxlength: 60 }), inp('s7', 'Wi-Fi password (shown to guests at tables)', s.wifi_password, { maxlength: 80 })),
      h('h3', { style: { margin: '1rem 0 0' } }, 'Links'), h('div', { class: 'fields' }, inp('s8', 'Google review link (https://…)', s.review_url, { maxlength: 300 }), inp('s9', 'Public website address used in QR codes', s.base_url, { placeholder: S.settings.base_url_detected })),
      h('button', { class: 'btn primary', onclick: (e) => save(async () => { await api('/api/admin/settings', { method: 'PUT', body: { restaurant_name: $('#s1').value, currency: $('#s2').value, tax_percent: Number($('#s3').value), tip_presets: $('#s4').value, points_per_unit: Number($('#s5').value), wifi_ssid: $('#s6').value, wifi_password: $('#s7').value, review_url: $('#s8').value, base_url: $('#s9').value } }); toast('Settings saved'); const r = await api('/api/admin/settings'); S.settings = r; setMoney(r.settings.locale, r.settings.currency); }, e.currentTarget) }, 'Save settings')),
      h('div', { class: 'card' }, h('h3', null, 'Payment & email services (server configuration)'), h('table', { class: 'data' },
        row('Payment provider', p.provider), row('Online payments (card, Apple Pay, Google Pay)', p.online_enabled ? 'Enabled' : 'Off — cash and bank transfer only'), row('Stripe keys', p.stripe_configured ? 'Set' : 'Not set'), row('Stripe webhook secret', p.stripe_webhook_configured ? 'Set' : 'Not set'), row('Receipt emails', p.email_configured ? 'Enabled' : 'Off — receipts are available by link')),
        h('p', { class: 'small muted' }, 'These are set as environment variables on the server (never in the browser). See the README for the exact steps.')));
  }
  const row = (a, b) => h('tr', null, h('td', null, a), h('td', null, b));
  boot();
})();
