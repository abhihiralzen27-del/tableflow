'use strict';
// Tiny shared helpers. All dynamic text goes through textContent (never innerHTML) so user input can't inject markup.
const $ = (s, r = document) => r.querySelector(s);
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) e.style.setProperty(sk, sv); else e.style[sk] = sv; } }
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'value') e.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected') e[k] = !!v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(Infinity)) { if (c == null || c === false) continue; e.append(c.nodeType ? c : document.createTextNode(String(c))); }
  return e;
}
async function api(path, { method = 'GET', body } = {}) {
  let r;
  try {
    r = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  } catch { const e = new Error('No connection. Check your internet and try again.'); e.status = 0; throw e; }
  let data = null; try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) { const e = new Error(data?.error || `Something went wrong (${r.status})`); e.status = r.status; throw e; }
  return data;
}
let fmt = null;
let fmt0 = null;
function setMoney(locale, currency) {
  try { fmt = new Intl.NumberFormat(locale, { style: 'currency', currency }); fmt0 = new Intl.NumberFormat(locale, { style: 'currency', currency, minimumFractionDigits: 0, maximumFractionDigits: 0 }); }
  catch { fmt = new Intl.NumberFormat('en', { style: 'currency', currency: 'USD' }); fmt0 = fmt; }
}
const money = (c) => { if (!fmt) setMoney('en', 'USD'); return (c % 100 === 0 ? fmt0 : fmt).format(c / 100); };
function toast(msg, bad) {
  let box = $('#toasts');
  if (!box) { box = h('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.append(box); }
  const t = h('div', { class: 'toast' + (bad ? ' bad' : ''), role: bad ? 'alert' : 'status' }, msg);
  box.append(t); setTimeout(() => t.remove(), 3800);
}
async function guard(fn, btn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn) btn.disabled = false; }
}
function sheet(title, content, { onClose } = {}) {
  const prev = document.activeElement;
  const close = () => { ov.remove(); document.removeEventListener('keydown', onKey); onClose?.(); prev?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const ov = h('div', { class: 'overlay', onclick: (e) => { if (e.target === ov) close(); } },
    h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, content));
  document.addEventListener('keydown', onKey);
  document.body.append(ov);
  (ov.querySelector('input,button,select,textarea') || ov).focus?.();
  return { close, el: ov };
}
function live(url, onChange, setStatus) {
  let es, t, last = 0;
  const fire = () => { clearTimeout(t); t = setTimeout(() => { last = Date.now(); onChange(); }, 150); };
  const open = () => {
    es = new EventSource(url);
    es.addEventListener('change', fire); es.addEventListener('open', () => { setStatus?.(true); fire(); });
    es.onerror = () => setStatus?.(false);
  };
  open();
  setInterval(() => { if (Date.now() - last > 20000) { last = Date.now(); onChange(); } }, 5000); // safety net if the stream drops
  return () => es.close();
}
const ago = (ts, now = Date.now()) => { const s = Math.max(0, Math.round((now - ts) / 1000)); return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s`; };
const mins = (ts, now = Date.now()) => Math.floor(Math.max(0, now - ts) / 60000);
