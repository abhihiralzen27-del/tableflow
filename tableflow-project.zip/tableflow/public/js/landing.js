'use strict';
$('#yr').textContent = new Date().getFullYear();
$('#lead').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('#lmsg'), btn = $('#lb'); msg.textContent = ''; msg.className = 'small';
  if (!$('#ln').value.trim() || !$('#le').value.trim()) { msg.textContent = 'Please enter your name and email.'; msg.className = 'small err'; return; }
  btn.disabled = true;
  try {
    await api('/api/leads', { method: 'POST', body: { name: $('#ln').value, email: $('#le').value, restaurant: $('#lr').value, message: $('#lm').value } });
    msg.textContent = '✅ Thank you! We will reply by email soon.'; e.target.reset();
  } catch (err) { msg.textContent = err.message; msg.className = 'small err'; }
  btn.disabled = false;
});
