'use strict';
(() => {
  const S = { data: null, station: localStorage.getItem('station') || 'all', online: true, me: null, chime: localStorage.getItem('chime') !== '0' };
  const seen = new Set(); let first = true;
  const root = $('#app');
  const NEXT = { new: 'preparing', preparing: 'ready' };
  const LABEL = { new: 'Tap to start', preparing: 'Cooking · tap when ready', ready: 'Ready · waiting for waiter' };
  function beep() {
    if (!S.chime) return;
    try { const c = new (window.AudioContext || window.webkitAudioContext)(); const o = c.createOscillator(), g = c.createGain(); o.connect(g); g.connect(c.destination); o.frequency.value = 880; g.gain.setValueAtTime(.15, c.currentTime); g.gain.exponentialRampToValueAtTime(.001, c.currentTime + .4); o.start(); o.stop(c.currentTime + .4); } catch { /* audio blocked */ }
  }
  async function load() {
    try {
      if (!S.me) S.me = (await api('/api/auth/me')).user;
      S.data = await api('/api/kitchen/state');
      let isNew = false;
      for (const o of S.data.orders) if (!seen.has(o.id)) { seen.add(o.id); isNew = true; }
      if (isNew && !first) { beep(); toast('🔔 New order'); }
      first = false; render();
    } catch (e) { if (e.status === 401) location.href = '/login'; else if (e.status === 403) root.replaceChildren(h('div', { class: 'empty' }, 'Your account cannot open this screen.')); }
  }
  function render() {
    const now = Date.now();
    const stations = ['all', ...S.data.stations];
    const tickets = S.data.orders.map((o) => ({ o, items: o.items.filter((i) => i.status !== 'served' && (S.station === 'all' || i.station === S.station)) })).filter((x) => x.items.length);
    root.replaceChildren(
      h('div', { class: 'stafftop' }, h('h1', null, '👨‍🍳 Kitchen'), h('span', { class: 'live' + (S.online ? '' : ' off'), title: S.online ? 'Live' : 'Reconnecting…', role: 'img', 'aria-label': S.online ? 'Live' : 'Offline' }),
        h('div', { class: 'chips grow', style: { margin: 0, padding: 0 }, role: 'group', 'aria-label': 'Station' }, stations.map((s) => h('button', { class: 'chip', 'aria-pressed': S.station === s, onclick: () => { S.station = s; localStorage.setItem('station', s); render(); } }, s === 'all' ? 'All stations' : s[0].toUpperCase() + s.slice(1)))),
        h('button', { class: 'btn sm', onclick: () => { S.chime = !S.chime; localStorage.setItem('chime', S.chime ? '1' : '0'); beep(); render(); } }, S.chime ? '🔔 Sound on' : '🔕 Sound off'),
        S.me?.role !== 'kitchen' ? h('a', { class: 'btn sm', href: S.me?.role === 'admin' ? '/admin' : '/floor' }, '← Back') : null,
        h('button', { class: 'btn sm', onclick: async () => { await api('/api/auth/logout', { method: 'POST' }); location.href = '/login'; } }, 'Sign out')),
      tickets.length ? h('div', { class: 'kgrid' }, tickets.map(({ o, items }) => ticket(o, items, now))) : h('div', { class: 'empty' }, h('div', { class: 'big' }, '✅'), h('h2', null, 'All caught up'), h('p', null, 'New orders appear here the moment staff send them.')));
  }
  function ticket(o, items, now) {
    const waitMin = Math.floor((now - o.sent_at) / 60000);
    const target = Math.max(...o.items.map((i) => i.prep_minutes));
    const cls = waitMin >= target * 1.5 ? 'late' : waitMin >= target ? 'warn' : '';
    const allReady = items.every((i) => i.status === 'ready');
    return h('article', { class: 'ticket ' + cls }, h('header', null, h('span', null, `Table ${o.table_label} · #${o.id}`), h('span', { 'data-since': o.sent_at }, ago(o.sent_at, now))),
      o.note ? h('div', { class: 'kitem', style: { cursor: 'default' } }, h('span', { class: 'nt' }, '📝 ' + o.note)) : null,
      items.map((i) => h('button', { class: 'kitem ' + i.status, onclick: () => advance(i), 'aria-label': `${i.qty} ${i.name}. ${LABEL[i.status]}` },
        h('span', { class: 'q' }, i.qty + '×'), h('span', { class: 'grow' }, h('b', null, i.name), i.size ? ` (${i.size})` : '', h('div', { class: 'small muted' }, `${i.station} · ${LABEL[i.status]}`), i.notes ? h('div', { class: 'nt' }, '⚠ ' + i.notes) : null),
        i.status === 'ready' ? h('span', null, '✅') : null)),
      !allReady ? h('button', { class: 'kitem', style: { justifyContent: 'center', fontWeight: 800 }, onclick: () => bump(items) }, 'Advance all →') : null);
  }
  async function advance(i) { if (NEXT[i.status]) await set([i.id], NEXT[i.status]); else if (i.status === 'ready') await set([i.id], 'preparing'); }
  async function bump(items) {
    const byStatus = { new: [], preparing: [] };
    items.forEach((i) => byStatus[i.status]?.push(i.id));
    if (byStatus.new.length) await set(byStatus.new, 'preparing'); else await set(byStatus.preparing, 'ready');
  }
  async function set(ids, status) { await guard(() => api('/api/staff/items/status', { method: 'POST', body: { ids, status } })); load(); }
  setInterval(() => { if (!S.data) return; const now = Date.now(); document.querySelectorAll('[data-since]').forEach((e) => { e.textContent = ago(Number(e.dataset.since), now); }); }, 1000);
  setInterval(() => { if (S.data) render(); }, 30000); // refresh late/warn colours
  load();
  live('/api/staff/stream', load, (ok) => { S.online = ok; if (S.data) render(); });
})();
