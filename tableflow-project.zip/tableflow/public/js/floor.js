'use strict';
(() => {
  const S = { d: null, me: null, online: true };
  const root = $('#app');
  const seen = { orders: new Set(), calls: new Set() }; let first = true;
  const CALLN = { waiter: '🙋 Needs waiter', water: '💧 Water', clean: '🧽 Clean table', bill: '🧾 Wants bill' };
  const STATUSN = { free: 'Free', busy: 'Dining', approve: 'Order to approve', help: 'Needs help', bill: 'Bill / payment', paid: 'Paid' };
  function beep() { try { const c = new (window.AudioContext || window.webkitAudioContext)(); const o = c.createOscillator(), g = c.createGain(); o.connect(g); g.connect(c.destination); o.frequency.value = 660; g.gain.setValueAtTime(.15, c.currentTime); g.gain.exponentialRampToValueAtTime(.001, c.currentTime + .5); o.start(); o.stop(c.currentTime + .5); } catch { /* blocked */ } }
  async function load() {
    try {
      if (!S.me) { S.me = (await api('/api/auth/me')).user; if (S.me.role === 'kitchen') { location.href = '/kitchen'; return; } }
      S.d = await api('/api/staff/state');
      setMoney(S.d.settings.locale, S.d.settings.currency);
      let alert = false;
      for (const o of S.d.orders) if (o.status === 'placed' && !seen.orders.has(o.id)) { seen.orders.add(o.id); alert = true; }
      for (const c of S.d.calls) if (!seen.calls.has(c.id)) { seen.calls.add(c.id); alert = true; }
      if (alert && !first) { beep(); toast('🔔 New request'); }
      first = false; render();
    } catch (e) { if (e.status === 401) location.href = '/login'; }
  }
  const act = (path, body, msg) => async (e) => { await guard(async () => { await api(path, { method: 'POST', body: body || {} }); if (msg) toast(msg); await load(); }, e?.currentTarget); };

  function render() {
    const d = S.d, now = d.now;
    const placed = d.orders.filter((o) => o.status === 'placed');
    const ready = d.orders.filter((o) => o.status === 'sent').flatMap((o) => o.items.filter((i) => i.status === 'ready').map((i) => ({ ...i, table: o.table_label })));
    root.replaceChildren(
      h('div', { class: 'stafftop' }, h('h1', null, `🗺️ ${d.settings.restaurant_name}`), h('span', { class: 'live' + (S.online ? '' : ' off'), role: 'img', 'aria-label': S.online ? 'Live' : 'Offline' }),
        h('div', { class: 'grow' }), h('a', { class: 'btn sm', href: '/kitchen' }, 'Kitchen view'), S.me.role === 'admin' ? h('a', { class: 'btn sm', href: '/admin' }, 'Admin') : null,
        h('button', { class: 'btn sm', onclick: async () => { await api('/api/auth/logout', { method: 'POST' }); location.href = '/login'; } }, 'Sign out')),
      h('div', { class: 'layout two' },
        h('section', null, h('div', { class: 'floor', role: 'group', 'aria-label': 'Restaurant floor map' }, d.tables.map(tableNode)),
          h('div', { class: 'legend' }, [['free', 'var(--card)', 'var(--line)'], ['busy', '#EAF2FB', 'var(--info)'], ['approve', '#F6E8FA', '#9C27B0'], ['help', '#FDE7E5', 'var(--danger)'], ['bill', '#FCF1D8', 'var(--gold)'], ['paid', '#E3F1E4', 'var(--ok)']].map(([k, c, b]) => h('span', { style: { '--c': c, '--b': b } }, STATUSN[k])))),
        h('section', { class: 'stack' },
          panel('Orders to approve', placed.length, placed.map((o) => h('div', null, h('div', { class: 'row between' }, h('b', null, `Table ${o.table_label} · #${o.id}`), h('span', { class: 'small muted' }, ago(o.created_at, now) + ' ago')),
            o.items.map((i) => h('div', { class: 'small' }, `${i.qty} × ${i.name}${i.size ? ' (' + i.size + ')' : ''}${i.notes ? ' — ⚠ ' + i.notes : ''}`)), o.note ? h('div', { class: 'small' }, '📝 ' + o.note) : null,
            h('div', { class: 'row', style: { marginTop: '.5rem' } }, h('button', { class: 'btn primary sm grow', onclick: act(`/api/staff/orders/${o.id}/send`, null, 'Sent to kitchen') }, '✅ Send to kitchen'), h('button', { class: 'btn danger sm', onclick: act(`/api/staff/orders/${o.id}/reject`) }, 'Reject')))), 'No orders waiting.'),
          panel('Guest requests', d.calls.length, d.calls.map((c) => h('div', { class: 'row between' }, h('div', null, h('b', null, `Table ${c.table_label}`), ' ', CALLN[c.kind] || c.kind, h('div', { class: 'small muted' }, `${ago(c.created_at, now)} ago${c.status === 'ack' ? ' · on the way' : ''}`)),
            h('div', { class: 'row' }, c.status === 'open' ? h('button', { class: 'btn sm', onclick: act(`/api/staff/calls/${c.id}`, { status: 'ack' }) }, 'On my way') : null, h('button', { class: 'btn sm ok', onclick: act(`/api/staff/calls/${c.id}`, { status: 'done' }) }, 'Done')))), 'No requests.'),
          panel('Payments to confirm', d.pending_payments.length, d.pending_payments.map((p) => h('div', { class: 'row between' }, h('div', null, h('b', null, `Table ${p.table_label}`), ` · ${p.method === 'cash' ? '💵 Cash' : '🏦 Bank transfer'}`, h('div', null, h('b', null, money(p.amount_cents + p.tip_cents)), h('span', { class: 'small muted' }, ` (tip ${money(p.tip_cents)})`))),
            h('div', { class: 'row' }, h('button', { class: 'btn sm ok', onclick: act(`/api/staff/payments/${p.id}/confirm`, null, 'Payment confirmed') }, 'Received'), h('button', { class: 'btn sm danger', onclick: act(`/api/staff/payments/${p.id}/reject`) }, 'Cancel')))), 'Nothing to confirm.'),
          panel('Ready to serve', ready.length, ready.map((i) => h('div', { class: 'row between' }, h('span', null, `Table ${i.table} · ${i.qty} × ${i.name}`), h('button', { class: 'btn sm ok', onclick: act('/api/staff/items/status', { ids: [i.id], status: 'served' }) }, 'Served'))), 'Nothing waiting in the pass.'),
          d.redemptions.length ? panel('Reward redemptions', d.redemptions.length, d.redemptions.map((r) => h('div', { class: 'row between' }, h('span', null, `Table ${r.table_label} · ${r.reward_name} · `, h('b', null, r.code)), h('button', { class: 'btn sm ok', onclick: act(`/api/staff/redemptions/${r.id}/fulfil`) }, 'Given'))), '') : null)));
  }
  function panel(title, n, rows, emptyText) {
    return h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h3', { style: { margin: 0 } }, title), n ? h('span', { class: 'badge warn' }, n) : null), n ? h('div', { class: 'list', style: { marginTop: '.5rem' } }, rows) : h('p', { class: 'muted small', style: { margin: '.4rem 0 0' } }, emptyText));
  }
  function tableNode(t) {
    const sub = t.status === 'free' ? `${t.seats} seats` : t.total ? money(t.remaining ? t.remaining : t.total) : STATUSN[t.status];
    const b = h('button', { class: 'tbl ' + t.status, style: { left: t.x + '%', top: t.y + '%' }, onclick: () => tableSheet(t), 'aria-label': `Table ${t.label}: ${STATUSN[t.status]}` }, t.label, h('small', null, sub), t.calls.length ? h('small', null, '🔔 ' + t.calls.length) : null);
    return b;
  }
  function tableSheet(t) {
    const orders = S.d.orders.filter((o) => o.table_label === t.label && o.status === 'sent');
    const placed = S.d.orders.filter((o) => o.table_label === t.label && o.status === 'placed');
    const body = h('div', { class: 'stack' }, h('div', { class: 'row between' }, h('h2', { style: { margin: 0 } }, `Table ${t.label}`), h('span', { class: 'badge' }, STATUSN[t.status])),
      t.since ? h('p', { class: 'muted small' }, `Seated for ${Math.floor((S.d.now - t.since) / 60000)} min · ${t.seats} seats`) : h('p', { class: 'muted small' }, `${t.seats} seats · no active orders`),
      placed.length ? h('p', { class: 'badge info' }, `${placed.length} order(s) waiting for approval`) : null,
      orders.map((o) => h('div', { class: 'card' }, h('b', null, `Order #${o.id}`), o.items.map((i) => h('div', { class: 'row between small' }, h('span', null, `${i.qty} × ${i.name}${i.size ? ' (' + i.size + ')' : ''}`), h('span', { class: 'status ' + i.status }, i.status))))),
      t.total ? h('div', { class: 'card row between' }, h('span', null, 'Bill incl. tax'), h('b', null, money(t.total)), h('span', { class: t.remaining ? 'badge warn' : 'badge ok' }, t.remaining ? `${money(t.remaining)} left` : 'Paid')) : null,
      h('button', { class: 'btn primary block', disabled: !(t.total && !t.remaining) && !(t.total === 0 && placed.length === 0 && false), onclick: async (e) => { await act(`/api/staff/tables/${t.id}/close`, {}, 'Table cleared')(e); sh.close(); } }, 'Close & clear table'),
      S.me.role === 'admin' && t.total && t.remaining ? h('button', { class: 'btn danger block', onclick: async (e) => { if (confirm('Close this table even though the bill is not fully paid?')) { await act(`/api/staff/tables/${t.id}/close`, { force: true }, 'Table force-closed')(e); sh.close(); } } }, 'Force close (unpaid)') : null,
      t.total && t.remaining ? h('p', { class: 'small muted' }, 'A table can be cleared once the bill is fully paid.') : null);
    const sh = sheet('Table ' + t.label, body);
  }
  setInterval(() => { if (S.d) { S.d.now = Date.now(); render(); } }, 30000);
  load();
  live('/api/staff/stream', load, (ok) => { S.online = ok; if (S.d) render(); });
})();
