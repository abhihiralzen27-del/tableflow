'use strict';
(() => {
  const TOKEN = location.pathname.split('/').pop();
  const A = (p) => `/api/t/${TOKEN}${p}`;
  const S = { data: null, tab: null, view: 'menu', q: '', cat: null, diet: null, avoid: new Set(), cart: [], games: null, quiz: null, me: null, reviewed: false };
  try { S.cart = JSON.parse(sessionStorage.getItem('cart:' + TOKEN) || '[]'); } catch { S.cart = []; }
  const saveCart = () => { try { sessionStorage.setItem('cart:' + TOKEN, JSON.stringify(S.cart)); } catch { /* private mode */ } };
  const root = $('#app');
  const STATUS = { placed: 'Waiting for staff', new: 'Order received', preparing: 'Cooking', ready: 'Ready', served: 'Served' };
  const DIETN = { veg: 'Vegetarian', vegan: 'Vegan', nonveg: 'Non-veg', egg: 'Contains egg' };
  const CALLN = { waiter: 'Call waiter', water: 'Water', clean: 'Clean table', bill: 'Request bill' };
  const METHODN = { cash: '💵 Cash', bank_transfer: '🏦 Bank transfer', card: '💳 Card', apple_pay: ' Apple Pay', google_pay: '🅖 Google Pay' };
  const itemById = (id) => S.data.categories.flatMap((c) => c.items).find((i) => i.id === id);
  const cartCount = () => S.cart.reduce((n, l) => n + l.qty, 0);
  const unitPrice = (it, size) => (it.deal_price_cents ?? it.price_cents) + (it.sizes.find((s) => s.name === size)?.delta_cents || 0);

  async function load() {
    try {
      S.data = await api(A('/menu'));
      setMoney(S.data.settings.locale, S.data.settings.currency);
      document.title = `${S.data.settings.restaurant_name} · Table ${S.data.table.label}`;
      S.me = S.data.guest;
      S.cart = S.cart.filter((l) => itemById(l.id));
      await refreshTab(true);
      live(A('/stream'), () => { refreshTab(); if (S.view === 'play') refreshGames(); }, null);
      const p = new URLSearchParams(location.search);
      if (p.get('paid')) toast('Thanks! Your payment is being confirmed.');
      if (p.get('cancelled')) toast('Payment was cancelled. You can try again.', true);
    } catch (e) {
      root.replaceChildren(h('div', { class: 'empty' }, h('div', { class: 'big' }, '🔍'), h('h2', null, 'This table link is not valid'), h('p', null, e.status === 404 ? 'Please scan the QR code on your table again, or ask a member of staff.' : e.message)));
    }
  }
  let busyTab = false;
  async function refreshTab(first) {
    if (busyTab) return; busyTab = true;
    try {
      const prev = S.tab;
      S.tab = await api(A('/tab'));
      if (prev) for (const o of S.tab.orders) for (const i of o.items) {
        const was = prev.orders.find((x) => x.id === o.id)?.items.find((x) => x.id === i.id);
        if (was && was.status !== 'ready' && i.status === 'ready') toast(`🍽️ ${i.name} is ready!`);
      }
      if (!first && prev && prev.remaining > 0 && S.tab.total > 0 && S.tab.remaining === 0) toast('✅ Bill fully paid. Thank you!');
      render();
    } catch (e) { if (first) throw e; } finally { busyTab = false; }
  }
  async function refreshGames() { try { S.games = await api(A('/games')); if (S.view === 'play') render(); } catch { /* ignore */ } }

  // ------------------------------------------------------------------ chrome
  function render() {
    if (!S.data) return;
    const focus = document.activeElement?.id;
    const sel = focus === 'q' ? [document.activeElement.selectionStart, document.activeElement.selectionEnd] : null;
    const views = { menu: viewMenu, cart: viewCart, bill: viewBill, play: viewPlay, more: viewMore };
    const openCalls = S.tab?.calls.filter((c) => c.kind !== 'bill') || [];
    root.replaceChildren(
      h('div', { class: 'app' },
        h('header', { class: 'topbar row between' },
          h('div', null, h('h1', null, S.data.settings.restaurant_name), h('div', { class: 'small muted' }, `Table ${S.data.table.label}`)),
          h('span', { class: 'pts', title: 'Reward points' }, `⭐ ${S.me.points}`)),
        h('main', { id: 'main' }, views[S.view]())),
      h('button', { class: 'fab', onclick: helpSheet, 'aria-label': 'Call a waiter or get help' }, openCalls.length ? '🔔 Help is coming' : '🔔 Need help?'),
      nav());
    if (focus === 'q') { const el = $('#q'); el.focus(); if (sel) el.setSelectionRange(...sel); }
  }
  function nav() {
    const unpaid = S.tab?.remaining > 0;
    const items = [['menu', '🍽️', 'Menu'], ['cart', '🛒', 'Cart', cartCount()], ['bill', '🧾', 'My table', unpaid ? '•' : 0], ['play', '🎮', 'Play'], ['more', '✨', 'More']];
    return h('nav', { class: 'bottomnav', 'aria-label': 'Main' }, h('div', { class: 'in' }, items.map(([v, ic, label, n]) =>
      h('button', { class: 'navbtn', 'aria-current': S.view === v ? 'page' : null, onclick: () => { S.view = v; if (v === 'play') { refreshGames(); } if (v === 'more') loadMe(); render(); window.scrollTo(0, 0); } },
        h('span', { class: 'ic', 'aria-hidden': 'true' }, ic), label, n ? h('span', { class: 'dot' }, n) : null))));
  }
  async function loadMe() { try { S.me2 = await api(A('/me')); S.me.points = S.me2.points; render(); } catch { /* ignore */ } }
  function go(v) { S.view = v; render(); window.scrollTo(0, 0); }

  // ------------------------------------------------------------------ menu
  function matches(it) {
    if (S.q && !(it.name + ' ' + it.description).toLowerCase().includes(S.q.toLowerCase())) return false;
    if (S.diet === 'veg' && !['veg', 'vegan'].includes(it.diet)) return false;
    if (S.diet === 'vegan' && it.diet !== 'vegan') return false;
    if (S.diet === 'nonveg' && it.diet !== 'nonveg') return false;
    for (const a of S.avoid) if (it.allergens.includes(a)) return false;
    return true;
  }
  function viewMenu() {
    const cats = S.data.categories.map((c) => ({ ...c, items: c.items.filter(matches) })).filter((c) => c.items.length && (!S.cat || S.cat === c.id));
    return h('div', null,
      S.data.deals.length ? h('div', null, S.data.deals.map((d) => h('div', { class: 'deal' }, h('b', null, '🎉 ' + d.title), h('div', { class: 'small' }, d.description)))) : null,
      h('label', { class: 'sr', for: 'q' }, 'Search the menu'),
      h('input', { id: 'q', type: 'search', placeholder: 'Search dishes…', value: S.q, oninput: (e) => { S.q = e.target.value; render(); } }),
      h('div', { class: 'chips', role: 'group', 'aria-label': 'Categories' }, h('button', { class: 'chip', 'aria-pressed': S.cat == null, onclick: () => { S.cat = null; render(); } }, 'All'),
        S.data.categories.map((c) => h('button', { class: 'chip', 'aria-pressed': S.cat === c.id, onclick: () => { S.cat = S.cat === c.id ? null : c.id; render(); } }, c.name))),
      h('div', { class: 'chips', role: 'group', 'aria-label': 'Dietary filter' },
        [['veg', '🥬 Veg'], ['vegan', '🌱 Vegan'], ['nonveg', '🍗 Non-veg']].map(([k, l]) => h('button', { class: 'chip', 'aria-pressed': S.diet === k, onclick: () => { S.diet = S.diet === k ? null : k; render(); } }, l))),
      h('details', { class: 'small', open: S.openAllergy || S.avoid.size ? true : null, ontoggle: (e) => { S.openAllergy = e.target.open; } }, h('summary', { class: 'muted' }, 'Allergies? Hide dishes containing…'),
        h('div', { class: 'chips', style: { flexWrap: 'wrap' } }, S.data.allergens.map((a) => h('button', { class: 'chip', 'aria-pressed': S.avoid.has(a), onclick: () => { S.avoid.has(a) ? S.avoid.delete(a) : S.avoid.add(a); render(); } }, a)))),
      S.avoid.size ? h('p', { class: 'small muted' }, 'Filters help you browse, but always tell your waiter about allergies — kitchens handle shared ingredients.') : null,
      cats.length ? cats.map((c) => h('section', null, h('h2', { style: { marginTop: '1.2rem' } }, c.name), c.items.map(dish))) :
        h('div', { class: 'empty' }, h('div', { class: 'big' }, '🥗'), h('p', null, 'No dishes match your filters.'), h('button', { class: 'btn', onclick: () => { S.q = ''; S.cat = null; S.diet = null; S.avoid.clear(); render(); } }, 'Clear filters')));
  }
  function dish(it) {
    return h('button', { class: 'dish', onclick: () => itemSheet(it), 'aria-label': `${it.name}, ${money(it.deal_price_cents ?? it.price_cents)}. Tap for details` },
      h('div', { class: 'em', 'aria-hidden': 'true' }, it.emoji),
      h('div', { class: 'grow' },
        h('h3', null, h('span', { class: 'diet ' + it.diet, title: DIETN[it.diet] }), it.name),
        h('div', { class: 'small muted' }, it.description),
        h('div', null, it.spice ? h('span', { class: 'tag', title: 'Spice level' }, '🌶'.repeat(it.spice) + ' spice') : null, it.allergens.slice(0, 3).map((a) => h('span', { class: 'tag al' }, a))),
        h('div', { class: 'price' }, it.deal_price_cents != null ? [h('s', null, money(it.price_cents)), money(it.deal_price_cents)] : (it.sizes.length ? `From ${money(it.price_cents + Math.min(...it.sizes.map((s) => s.delta_cents)))}` : money(it.price_cents)))));
  }
  function itemSheet(it) {
    let size = it.sizes.length ? it.sizes[it.sizes.length - 1].name : '', qty = 1;
    const body = h('div');
    const draw = () => {
      body.replaceChildren(
        h('div', { class: 'row' }, h('div', { class: 'em', style: { fontSize: '3rem' }, 'aria-hidden': 'true' }, it.emoji), h('div', null, h('h2', { style: { margin: 0 } }, it.name), h('span', { class: 'diet ' + it.diet }), h('span', { class: 'small muted' }, DIETN[it.diet]))),
        h('p', { class: 'muted' }, it.description),
        h('div', { class: 'stack' },
          h('div', null, h('b', null, 'Spice level: '), it.spice ? '🌶'.repeat(it.spice) + ['', ' Mild', ' Medium', ' Hot'][it.spice] : 'Not spicy'),
          h('div', null, h('b', null, 'Allergens: '), it.allergens.length ? it.allergens.map((a) => h('span', { class: 'tag al' }, a)) : 'None declared'),
          h('div', { class: 'small muted' }, `About ${it.prep_minutes} min preparation`)),
        it.sizes.length ? h('div', { role: 'radiogroup', 'aria-label': 'Size' }, h('label', null, 'Size'), it.sizes.map((s) => h('label', { class: 'opt' + (size === s.name ? ' on' : ''), style: { fontWeight: 600 } },
          h('input', { type: 'radio', name: 'size', checked: size === s.name, onchange: () => { size = s.name; draw(); } }), h('span', { class: 'grow' }, s.name), h('span', null, money(unitPrice(it, s.name)))))) : null,
        h('label', { for: 'dn' }, 'Special request (optional)'), h('input', { id: 'dn', type: 'text', maxlength: 150, placeholder: 'e.g. less spicy, no onions' }),
        h('div', { class: 'row between', style: { marginTop: '1.2rem' } },
          h('div', { class: 'qty', role: 'group', 'aria-label': 'Quantity' }, h('button', { 'aria-label': 'Less', onclick: () => { qty = Math.max(1, qty - 1); draw(); } }, '−'), h('span', { 'aria-live': 'polite' }, qty), h('button', { 'aria-label': 'More', onclick: () => { qty = Math.min(20, qty + 1); draw(); } }, '+')),
          h('button', { class: 'btn primary grow', onclick: () => { addToCart(it, size, qty, $('#dn').value.trim()); sh.close(); } }, `Add · ${money(unitPrice(it, size) * qty)}`)));
    };
    const sh = sheet(it.name, body); draw();
  }
  function addToCart(it, size, qty, notes) {
    const ex = S.cart.find((l) => l.id === it.id && l.size === size && l.notes === notes);
    if (ex) ex.qty = Math.min(20, ex.qty + qty); else S.cart.push({ id: it.id, size, qty, notes });
    saveCart(); toast(`Added ${it.name}`); render();
  }

  // ------------------------------------------------------------------ cart
  function viewCart() {
    if (!S.cart.length) return h('div', { class: 'empty' }, h('div', { class: 'big' }, '🛒'), h('h2', null, 'Your cart is empty'), h('p', null, 'Browse the menu and add something delicious.'), h('button', { class: 'btn primary', onclick: () => go('menu') }, 'See the menu'));
    const sub = S.cart.reduce((n, l) => n + unitPrice(itemById(l.id), l.size) * l.qty, 0);
    return h('div', { class: 'stack' }, h('h2', null, 'Your order'),
      h('div', { class: 'card list' }, S.cart.map((l, idx) => { const it = itemById(l.id); return h('div', { class: 'row between' },
        h('div', { class: 'grow' }, h('b', null, it.name), l.size ? ` (${l.size})` : '', l.notes ? h('div', { class: 'small muted' }, '“' + l.notes + '”') : null, h('div', { class: 'small' }, money(unitPrice(it, l.size)))),
        h('div', { class: 'qty' }, h('button', { 'aria-label': `Less ${it.name}`, onclick: () => { l.qty--; if (l.qty < 1) S.cart.splice(idx, 1); saveCart(); render(); } }, '−'), h('span', null, l.qty), h('button', { 'aria-label': `More ${it.name}`, onclick: () => { l.qty = Math.min(20, l.qty + 1); saveCart(); render(); } }, '+'))); })),
      h('label', { for: 'on' }, 'Note for the kitchen (optional)'), h('textarea', { id: 'on', maxlength: 300, placeholder: 'Allergies, timing, anything we should know' }),
      h('div', { class: 'card row between' }, h('span', null, 'Subtotal (tax added on the bill)'), h('b', null, money(sub))),
      h('button', { class: 'btn primary block', id: 'place', onclick: placeOrder }, 'Send order to staff'),
      h('p', { class: 'small muted center' }, 'A member of staff confirms your order and sends it to the kitchen.'));
  }
  async function placeOrder(e) {
    await guard(async () => {
      await api(A('/orders'), { method: 'POST', body: { items: S.cart.map((l) => ({ id: l.id, size: l.size, qty: l.qty, notes: l.notes })), note: $('#on')?.value || '' } });
      S.cart = []; saveCart(); toast('Order sent! Staff will confirm it shortly.'); await refreshTab(); go('bill');
    }, e.currentTarget);
  }

  // ------------------------------------------------------------------ bill / my table
  function viewBill() {
    const t = S.tab;
    if (!t.orders.length) return h('div', { class: 'empty' }, h('div', { class: 'big' }, '🧾'), h('h2', null, 'No orders yet'), h('p', null, 'Once you order, you can follow every dish here.'), h('button', { class: 'btn primary', onclick: () => go('menu') }, 'See the menu'));
    return h('div', { class: 'stack' }, h('h2', null, 'Your table'),
      t.orders.map((o) => h('div', { class: 'card' },
        h('div', { class: 'row between' }, h('b', null, `Order #${o.id}`), h('span', { class: 'status ' + (o.status === 'placed' ? 'placed' : 'new') }, o.status === 'placed' ? 'Waiting for staff to confirm' : 'Sent to kitchen')),
        o.items.map((i) => h('div', { class: 'row between', style: { marginTop: '.5rem' } },
          h('div', null, `${i.qty} × ${i.name}`, i.size ? ` (${i.size})` : '', i.paid ? h('span', { class: 'badge ok', style: { marginLeft: '.4rem' } }, 'paid') : null),
          o.status === 'placed' ? null : h('span', { class: 'status ' + i.status }, STATUS[i.status] || i.status))))),
      t.total ? billCard(t) : h('p', { class: 'muted small center' }, 'Your bill appears once the staff confirm your order.'),
      t.total && t.remaining === 0 ? reviewCard() : null);
  }
  function billCard(t) {
    return h('div', { class: 'card' }, h('h3', null, 'Bill'),
      h('table', { class: 'totals', style: { width: '100%' } },
        h('tr', null, h('td', null, 'Subtotal'), h('td', { class: 'r' }, money(t.subtotal))),
        h('tr', null, h('td', null, `Tax (${S.data.settings.tax_percent}%)`), h('td', { class: 'r' }, money(t.tax))),
        h('tr', null, h('td', null, 'Paid so far'), h('td', { class: 'r' }, money(t.paid))),
        h('tr', { class: 't' }, h('td', null, 'Left to pay'), h('td', { class: 't r' }, money(t.remaining)))),
      t.payments.filter((p) => p.status === 'awaiting_staff').map((p) => h('p', { class: 'badge warn' }, `${money(p.amount_cents + p.tip_cents)} by ${p.method.replace('_', ' ')} waiting for staff`)),
      t.payments.filter((p) => p.receipt).map((p) => h('div', null, h('a', { href: '/r/' + p.receipt, target: '_blank', rel: 'noopener' }, `Receipt · ${money(p.amount_cents + p.tip_cents)}`))),
      t.remaining > 0 ? h('div', { class: 'row', style: { marginTop: '.8rem' } }, h('button', { class: 'btn primary grow', onclick: paySheet }, 'Pay / split bill'), h('button', { class: 'btn', onclick: () => callStaff('bill') }, 'Ask for bill')) : h('p', { class: 'badge ok' }, '✅ Fully paid'));
  }
  function reviewCard() {
    if (S.reviewed) return h('div', { class: 'card center' }, h('b', null, 'Thanks for your feedback! 💛'), S.data.settings.review_url ? h('p', null, h('a', { href: S.data.settings.review_url, target: '_blank', rel: 'noopener' }, 'Share it on Google too')) : null);
    return h('div', { class: 'card center' }, h('h3', null, 'How was your visit?'), h('div', { class: 'stars' }, [1, 2, 3, 4, 5].map((n) => h('button', { 'aria-label': `${n} star${n > 1 ? 's' : ''}`, onclick: () => reviewSheet(n) }, '⭐'))));
  }
  function reviewSheet(rating) {
    const sh = sheet('Review', h('div', { class: 'stack' }, h('h2', null, `${'⭐'.repeat(rating)} Thank you!`), h('label', { for: 'rc' }, 'Anything you want to add? (optional)'), h('textarea', { id: 'rc', maxlength: 600 }),
      h('button', { class: 'btn primary block', onclick: async (e) => guard(async () => { await api(A('/review'), { method: 'POST', body: { rating, comment: $('#rc').value } }); S.reviewed = true; sh.close(); render(); }, e.currentTarget) }, 'Send review')));
  }
  async function callStaff(kind) { await guard(async () => { const r = await api(A('/call'), { method: 'POST', body: { kind } }); toast(r.already ? 'Staff already know — help is on the way.' : 'Staff notified. Someone will be with you shortly.'); await refreshTab(); }); }
  function helpSheet() {
    const sh = sheet('Help', h('div', { class: 'stack' }, h('h2', null, 'How can we help?'),
      Object.entries(CALLN).map(([k, l]) => h('button', { class: 'btn block', onclick: async () => { sh.close(); await callStaff(k); } }, `${{ waiter: '🙋', water: '💧', clean: '🧽', bill: '🧾' }[k]} ${l}`)),
      S.tab?.calls.length ? h('p', { class: 'small muted' }, 'Open requests: ' + S.tab.calls.map((c) => `${CALLN[c.kind]} (${c.status === 'ack' ? 'on the way' : 'sent'})`).join(', ')) : null));
  }

  // ------------------------------------------------------------------ pay
  function paySheet() {
    const t = S.tab, st = S.data.settings;
    const P = { mode: 'equal', parts: 2, tip: st.tip_presets.includes(10) ? 10 : (st.tip_presets[1] ?? 0), customTip: '', method: st.methods[0], email: '', ids: new Set() };
    const unpaid = t.orders.filter((o) => o.status === 'sent').flatMap((o) => o.items).filter((i) => !i.paid);
    const body = h('div', { class: 'stack' });
    const base = () => {
      if (P.mode === 'all') return t.remaining;
      if (P.mode === 'equal') return Math.min(t.remaining, Math.ceil(t.remaining / P.parts));
      const sub = unpaid.filter((i) => P.ids.has(i.id)).reduce((n, i) => n + i.qty * i.unit_price_cents, 0);
      const rest = unpaid.some((i) => !P.ids.has(i.id));
      return !rest && P.ids.size ? t.remaining : Math.min(t.remaining, Math.round(sub * (1 + st.tax_percent / 100)));
    };
    const tipOf = (b) => (P.tip === 'custom' ? Math.round((parseFloat(P.customTip) || 0) * 100) : Math.round((b * P.tip) / 100));
    const draw = () => {
      const b = base(), tip = tipOf(b);
      body.replaceChildren(h('h2', null, 'Pay your share'),
        h('div', { class: 'chips', role: 'group', 'aria-label': 'How to split' }, [['all', 'Whole bill'], ['equal', 'Split equally'], ['items', 'Pick my items']].map(([k, l]) => h('button', { class: 'chip', 'aria-pressed': P.mode === k, onclick: () => { P.mode = k; draw(); } }, l))),
        P.mode === 'equal' ? h('div', { class: 'row between card' }, h('span', null, 'Number of people still paying'), h('div', { class: 'qty' }, h('button', { 'aria-label': 'Fewer people', onclick: () => { P.parts = Math.max(1, P.parts - 1); draw(); } }, '−'), h('span', null, P.parts), h('button', { 'aria-label': 'More people', onclick: () => { P.parts = Math.min(20, P.parts + 1); draw(); } }, '+'))) : null,
        P.mode === 'items' ? h('div', null, unpaid.map((i) => h('label', { class: 'opt' + (P.ids.has(i.id) ? ' on' : ''), style: { fontWeight: 500 } }, h('input', { type: 'checkbox', checked: P.ids.has(i.id), onchange: (e) => { e.target.checked ? P.ids.add(i.id) : P.ids.delete(i.id); draw(); } }), h('span', { class: 'grow' }, `${i.qty} × ${i.name}${i.size ? ' (' + i.size + ')' : ''}`), h('span', null, money(i.qty * i.unit_price_cents))))) : null,
        h('div', null, h('label', null, 'Add a tip'), h('div', { class: 'chips' }, st.tip_presets.map((p) => h('button', { class: 'chip', 'aria-pressed': P.tip === p, onclick: () => { P.tip = p; draw(); } }, p ? p + '%' : 'No tip')), h('button', { class: 'chip', 'aria-pressed': P.tip === 'custom', onclick: () => { P.tip = 'custom'; draw(); setTimeout(() => $('#ct')?.focus()); } }, 'Custom')),
          P.tip === 'custom' ? h('input', { id: 'ct', type: 'number', min: 0, step: '0.01', inputmode: 'decimal', placeholder: 'Tip amount', value: P.customTip, oninput: (e) => { P.customTip = e.target.value; const x = e.target.selectionStart; const pb = $('#paybtn'); pb.textContent = `Pay ${money(base() + tipOf(base()))}`; } }) : null),
        h('div', { role: 'radiogroup', 'aria-label': 'Payment method' }, h('label', null, 'Pay with'), st.methods.map((m) => h('label', { class: 'opt' + (P.method === m ? ' on' : ''), style: { fontWeight: 600 } }, h('input', { type: 'radio', name: 'm', checked: P.method === m, onchange: () => { P.method = m; draw(); } }), METHODN[m]))),
        ['cash', 'bank_transfer'].includes(P.method) ? h('p', { class: 'small muted' }, 'A waiter will come to your table to collect cash or confirm your bank transfer.') : null,
        h('label', { for: 'em' }, 'Email for your receipt (optional)'), h('input', { id: 'em', type: 'email', autocomplete: 'email', placeholder: 'you@example.com', value: P.email, oninput: (e) => { P.email = e.target.value; } }),
        h('div', { class: 'card row between' }, h('span', null, `Bill ${money(b)} + tip ${money(tip)}`)),
        h('button', { class: 'btn primary block', id: 'paybtn', disabled: b < 1 || (P.mode === 'items' && !P.ids.size), onclick: submit }, `Pay ${money(b + tip)}`));
    };
    async function submit(e) {
      await guard(async () => {
        const b = base();
        const body2 = { method: P.method, mode: P.mode, tip_cents: tipOf(b), email: P.email || undefined };
        if (P.mode === 'equal') body2.parts = P.parts; if (P.mode === 'items') body2.item_ids = [...P.ids];
        const r = await api(A('/pay'), { method: 'POST', body: body2 });
        sh.close();
        if (r.redirect) { location.href = r.redirect; return; }
        toast(r.status === 'paid' ? '✅ Payment successful!' : 'Request sent. A waiter is coming to your table.');
        await refreshTab();
      }, e.currentTarget);
    }
    const sh = sheet('Pay', body); draw();
  }

  // ------------------------------------------------------------------ play
  function viewPlay() {
    const g = S.games;
    return h('div', { class: 'stack' }, h('h2', null, 'Play while you wait'), h('p', { class: 'muted' }, 'Win games to earn reward points. Challenge another table or test your food knowledge.'),
      h('div', { class: 'card' }, h('h3', null, '❌⭕ Tic-Tac-Toe'), g?.mine ? board(g.mine) : lobby(g)),
      h('div', { class: 'card' }, h('h3', null, '🧠 Food quiz'), quizView()));
  }
  function lobby(g) {
    return h('div', { class: 'stack' }, h('button', { class: 'btn primary block', onclick: (e) => guard(async () => { await api(A('/games'), { method: 'POST' }); await refreshGames(); }, e.currentTarget) }, 'Start a new game'),
      g?.open.length ? h('div', null, h('b', null, 'Open games'), h('div', { class: 'list' }, g.open.map((x) => h('div', { class: 'row between' }, h('span', null, `${x.p1} · Table ${x.p1_table}`), h('button', { class: 'btn sm', onclick: (e) => guard(async () => { await api(A(`/games/${x.id}/join`), { method: 'POST' }); await refreshGames(); }, e.currentTarget) }, 'Join'))))) : h('p', { class: 'small muted' }, 'No one is waiting for an opponent right now. Start a game and others can join.'));
  }
  function board(m) {
    const done = m.status === 'won' || m.status === 'draw';
    const msg = m.status === 'open' ? 'Waiting for an opponent to join…' : m.status === 'draw' ? "It's a draw! +3 points" : m.status === 'won' ? (m.winner === m.mine ? '🎉 You won! +10 points' : 'You lost this one. Rematch?') : (m.turn === m.mine ? 'Your turn' : "Opponent's turn…");
    return h('div', null, h('p', { class: 'center' }, h('b', null, msg), m.p2 ? h('div', { class: 'small muted' }, `${m.p1} (X, table ${m.p1_table}) vs ${m.p2} (O, table ${m.p2_table}) · you are ${m.mine}`) : null),
      h('div', { class: 'ttt', role: 'grid', 'aria-label': 'Tic-tac-toe board' }, [...m.board].map((c, i) => h('button', { 'data-m': c, 'aria-label': `Square ${i + 1}${c !== '-' ? ' ' + c : ''}`, disabled: done || m.status !== 'playing' || c !== '-' || m.turn !== m.mine, onclick: (e) => guard(async () => { await api(A(`/games/${m.id}/move`), { method: 'POST', body: { cell: i } }); await refreshGames(); await loadMe(); }, e.currentTarget) }, c === '-' ? '' : c))),
      h('button', { class: 'btn block', onclick: (e) => guard(async () => { await api(A(`/games/${m.id}/leave`), { method: 'POST' }); S.games = null; await refreshGames(); }, e.currentTarget) }, done ? 'Back to lobby' : 'Leave game'));
  }
  function quizView() {
    const q = S.quiz;
    if (!q) return h('button', { class: 'btn block', onclick: nextQuiz }, 'Play a question');
    if (q.done) return h('p', { class: 'muted' }, 'You have answered every question. Amazing! 🏆');
    return h('div', { class: 'stack' }, h('b', null, q.question), q.options.map((o, i) => h('button', { class: 'btn block', disabled: q.result != null, style: q.result && i === q.result.answer ? { background: '#E3F1E4', borderColor: 'var(--ok)' } : (q.result && q.picked === i ? { background: '#FBE3E1', borderColor: 'var(--danger)' } : {}), onclick: (e) => guard(async () => { q.picked = i; q.result = await api(A('/quiz'), { method: 'POST', body: { qid: q.qid, choice: i } }); S.me.points = q.result.points; render(); }, e.currentTarget) }, o)),
      q.result ? h('div', { class: 'center' }, h('p', null, h('b', null, q.result.correct ? (q.result.gained ? `Correct! +${q.result.gained} points` : 'Correct!') : 'Not quite!')), h('button', { class: 'btn primary', onclick: nextQuiz }, 'Next question')) : null);
  }
  async function nextQuiz() { await guard(async () => { S.quiz = await api(A('/quiz')); render(); }); }

  // ------------------------------------------------------------------ more
  function viewMore() {
    const s = S.data.settings, me = S.me2;
    return h('div', { class: 'stack' }, h('h2', null, 'More'),
      s.wifi_ssid ? h('div', { class: 'wifi' }, h('div', { class: 'small' }, '📶 Free Wi-Fi'), h('div', null, 'Network: ', h('b', null, s.wifi_ssid)), s.wifi_password ? h('div', { class: 'row between', style: { marginTop: '.5rem' } }, h('code', null, s.wifi_password), h('button', { class: 'btn sm', onclick: async () => { try { await navigator.clipboard.writeText(s.wifi_password); toast('Password copied'); } catch { toast('Select and copy the password', true); } } }, 'Copy')) : h('div', null, 'No password needed')) : null,
      h('div', { class: 'card stack' }, h('div', { class: 'row between' }, h('h3', { style: { margin: 0 } }, '⭐ Rewards'), h('b', null, `${S.me.points} points`)), h('p', { class: 'small muted' }, 'Earn points when you pay, win games and answer quiz questions.'),
        S.data.rewards.length ? S.data.rewards.map((r) => h('div', { class: 'row between' }, h('span', null, `${r.name} · ${r.cost_points} pts`), h('button', { class: 'btn sm primary', disabled: S.me.points < r.cost_points, onclick: (e) => guard(async () => { const x = await api(A('/redeem'), { method: 'POST', body: { reward_id: r.id } }); S.me.points = x.points; toast('Show this to your waiter'); await loadMe(); }, e.currentTarget) }, 'Redeem'))) : h('p', { class: 'small muted' }, 'No rewards available yet.'),
        me?.redemptions.length ? h('div', null, h('b', null, 'Your reward codes'), me.redemptions.map((r) => h('div', { class: 'small' }, `${r.reward_name}: `, h('b', null, r.code), r.status === 'fulfilled' ? ' (used)' : ' — show to staff'))) : null),
      h('div', { class: 'card' }, h('h3', null, 'Your name'), h('div', { class: 'row' }, h('label', { class: 'sr', for: 'nn' }, 'Nickname'), h('input', { id: 'nn', type: 'text', maxlength: 20, value: me?.nickname || S.data.guest.nickname }), h('button', { class: 'btn', onclick: (e) => guard(async () => { await api(A('/guest'), { method: 'POST', body: { nickname: $('#nn').value } }); toast('Saved'); }, e.currentTarget) }, 'Save')), h('p', { class: 'small muted' }, 'Shown to other tables when you play games.')),
      h('div', { class: 'card stack' }, h('h3', null, 'Need something?'), h('div', { class: 'row wrap' }, Object.entries(CALLN).map(([k, l]) => h('button', { class: 'btn sm', onclick: () => callStaff(k) }, l)))),
      s.review_url ? h('a', { class: 'btn block', href: s.review_url, target: '_blank', rel: 'noopener' }, '⭐ Review us on Google') : null);
  }

  load();
})();
