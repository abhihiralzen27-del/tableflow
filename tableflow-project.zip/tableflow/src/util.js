'use strict';
const crypto = require('node:crypto');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);

// ---------- validation ----------
function str(v, { min = 0, max = 200, name = 'value' } = {}) {
  if (typeof v !== 'string') throw bad(`${name} must be text`);
  const s = v.trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  if (s.length < min || s.length > max) throw bad(`${name} must be ${min}-${max} characters`);
  return s;
}
function int(v, { min = 0, max = 1e9, name = 'value' } = {}) {
  if (!Number.isInteger(v) || v < min || v > max) throw bad(`${name} must be a whole number ${min}-${max}`);
  return v;
}
function oneOf(v, list, name = 'value') {
  if (!list.includes(v)) throw bad(`${name} must be one of: ${list.join(', ')}`);
  return v;
}
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@.]{2,}$/;
function email(v, name = 'email') {
  const s = str(v, { min: 3, max: 254, name }).toLowerCase();
  if (!EMAIL_RE.test(s)) throw bad(`${name} is not a valid email address`);
  return s;
}
function strList(v, allowed, name) {
  if (v == null) return [];
  if (!Array.isArray(v) || v.length > 30) throw bad(`${name} must be a list`);
  for (const x of v) if (!allowed.includes(x)) throw bad(`${name} contains an unknown value`);
  return [...new Set(v)];
}

// ---------- crypto ----------
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const token = (bytes = 24) => crypto.randomBytes(bytes).toString('hex');
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const h = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  return `scrypt$${salt}$${h}`;
}
const DUMMY_HASH = hashPassword('dummy-password-for-timing');
function verifyPassword(pw, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const expected = Buffer.from(parts[2], 'hex');
  const actual = crypto.scryptSync(pw, parts[1], 64, { N: 16384, r: 8, p: 1 });
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
function checkPasswordStrength(pw) {
  if (typeof pw !== 'string' || pw.length < 10 || pw.length > 128) throw bad('Password must be 10-128 characters');
  if (!/[a-zA-Z]/.test(pw) || !/[0-9]/.test(pw)) throw bad('Password must contain letters and numbers');
}

// ---------- rate limiting (in-memory; fine for a single instance) ----------
const hits = new Map();
function rateLimit(key, limit, windowMs) {
  const now = Date.now();
  let a = hits.get(key);
  if (!a) { a = []; hits.set(key, a); }
  while (a.length && a[0] <= now - windowMs) a.shift();
  if (a.length >= limit) return false;
  a.push(now);
  return true;
}
setInterval(() => {
  const cutoff = Date.now() - 3600e3;
  for (const [k, a] of hits) if (!a.length || a[a.length - 1] < cutoff) hits.delete(k);
}, 60e3).unref();

// ---------- realtime (Server-Sent Events) ----------
const channels = new Map();
let sseCount = 0;
const sseByIp = new Map();
function subscribe(names, req, res, ip) {
  names = [].concat(names);
  if (sseCount > 3000 || (sseByIp.get(ip) || 0) >= 400) throw new HttpError(429, 'Too many live connections');
  res.writeHead(200, {
    'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no',
  });
  res.write('retry: 3000\n\n');
  for (const name of names) { if (!channels.has(name)) channels.set(name, new Set()); channels.get(name).add(res); }
  sseCount++;
  sseByIp.set(ip, (sseByIp.get(ip) || 0) + 1);
  req.on('close', () => {
    for (const name of names) channels.get(name)?.delete(res);
    sseCount--;
    sseByIp.set(ip, Math.max(0, (sseByIp.get(ip) || 1) - 1));
  });
}
function publish(name, type = 'change', data = {}) {
  const set = channels.get(name);
  if (!set) return;
  const msg = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of set) res.write(msg);
}
setInterval(() => { for (const set of channels.values()) for (const res of set) res.write(': ping\n\n'); }, 25e3).unref();

// ---------- misc ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

module.exports = {
  HttpError, bad, str, int, oneOf, email, strList, sha256, token, hashPassword, verifyPassword, DUMMY_HASH,
  checkPasswordStrength, rateLimit, subscribe, publish, esc, parseCookies,
};
