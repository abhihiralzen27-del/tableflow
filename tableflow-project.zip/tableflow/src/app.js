'use strict';
// Business logic + routes. Exported as a request handler so tests can start it on any port.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const U = require('./util');
const { HttpError, bad, str, int, oneOf, email, strList } = U;
const { db, tx, getSettings, setSetting } = require('./db');
const { qrSvg } = require('./qr');
const { QUIZ } = require('./quiz');
const payments = require('./payments');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const BRAND = process.env.BRAND || 'TableFlow';
const ALLERGENS = ['gluten', 'dairy', 'nuts', 'peanuts', 'egg', 'soy', 'fish', 'shellfish', 'sesame'];
const DIETS = ['veg', 'vegan', 'nonveg', 'egg'];
const STATIONS = ['kitchen', 'grill', 'bar', 'dessert'];
const CALL_KINDS = ['waiter', 'water', 'clean', 'bill'];
const now = () => Date.now();
const isProd = process.env.NODE_ENV === 'production';
const baseUrlEnv = () => (process.env.BASE_URL || '').replace(/\/+$/, '');
const secureCookies = () => baseUrlEnv().startsWith('https://');

// ---------------------------------------------------------------- routing
const routes = [];
function route(method, pattern, opts, handler) {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, opts, handler });
}
const ok = (data = {}) => ({ ok: true, ...data });

// ---------------------------------------------------------------- auth helpers
function userFromReq(req) {
  const sid = U.parseCookies(req.headers.cookie).sid;
  if (!sid || !/^[a-f0-9]{48}$/.test(sid)) return null;
  const row = db.prepare(`SELECT u.id,u.email,u.name,u.role FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.id=? AND s.expires_at>? AND u.active=1`).get(U.sha256(sid), now());
  return row || null;
}
function need(ctx, ...roles) {
  if (!ctx.user) throw new HttpError(401, 'Please sign in');
  if (roles.length && !roles.includes(ctx.user.role)) throw new HttpError(403, 'You do not have access to this');
}
function setCookie(res, name, value, maxAgeSec) {
  const parts = [`${name}=${value}`, 'Path=/', 'HttpOnly', 'SameSite=Strict', `Max-Age=${maxAgeSec}`];
  if (secureCookies()) parts.push('Secure');
  const prev = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [].concat(prev, parts.join('; ')));
}
const audit = (ctx, action, detail = '') => db.prepare('INSERT INTO audit_log(user_id,action,detail,created_at) VALUES(?,?,?,?)').run(ctx.user?.id ?? null, action, String(detail).slice(0, 300), now());

// ---------------------------------------------------------------- domain helpers
function tableByToken(t) {
  if (!/^[a-f0-9]{32}$/.test(t)) throw new HttpError(404, 'Table not found');
  const row = db.prepare('SELECT * FROM dining_tables WHERE token=? AND active=1').get(t);
  if (!row) throw new HttpError(404, 'Table not found');
  return row;
}
function ensureGuest(ctx, table) {
  const gid = U.parseCookies(ctx.req.headers.cookie).gid;
  let g = gid && /^[a-f0-9]{32}$/.test(gid) ? db.prepare('SELECT * FROM guests WHERE id=?').get(gid) : null;
  if (!g) {
    if (!U.rateLimit('newguest:' + ctx.ip, 400, 3600e3)) throw new HttpError(429, 'Too many new visitors from this network. Please try again later.');
    const id = U.token(16);
    const nick = 'Guest ' + Math.floor(1000 + Math.random() * 9000);
    db.prepare('INSERT INTO guests(id,nickname,created_at) VALUES(?,?,?)').run(id, nick, now());
    g = db.prepare('SELECT * FROM guests WHERE id=?').get(id);
    setCookie(ctx.res, 'gid', id, 60 * 60 * 24 * 365);
  }
  return g;
}
function addPoints(guestId, delta, reason) {
  if (!guestId || !delta) return;
  db.prepare('UPDATE guests SET points=MAX(0,points+?) WHERE id=?').run(delta, guestId);
  db.prepare('INSERT INTO points_ledger(guest_id,delta,reason,created_at) VALUES(?,?,?,?)').run(guestId, delta, reason, now());
}
const parseItem = (r) => ({ ...r, sizes: JSON.parse(r.sizes), allergens: JSON.parse(r.allergens), available: !!r.available });
function effectivePrice(item) {
  const d = db.prepare('SELECT deal_price_cents FROM deals WHERE active=1 AND item_id=? AND deal_price_cents IS NOT NULL ORDER BY deal_price_cents LIMIT 1').get(item.id);
  return d ? Math.min(d.deal_price_cents, item.price_cents) : item.price_cents;
}
function menuData() {
  const cats = db.prepare('SELECT * FROM categories ORDER BY sort,id').all();
  const items = db.prepare('SELECT * FROM items WHERE available=1 ORDER BY sort,id').all().map(parseItem);
  const deals = db.prepare('SELECT * FROM deals WHERE active=1 ORDER BY id').all();
  const dealPrice = new Map(deals.filter((d) => d.item_id && d.deal_price_cents != null).map((d) => [d.item_id, d.deal_price_cents]));
  for (const it of items) { it.deal_price_cents = dealPrice.has(it.id) ? Math.min(dealPrice.get(it.id), it.price_cents) : null; }
  return { categories: cats.map((c) => ({ ...c, items: items.filter((i) => i.category_id === c.id) })).filter((c) => c.items.length), deals };
}
const taxPct = () => Math.max(0, Number(getSettings().tax_percent) || 0);

// Releases reservations held by payments that were never completed.
function expireStalePayments(tableId) {
  const cutoff = now() - 30 * 60e3;
  const stale = db.prepare(`SELECT id FROM payments WHERE table_id=? AND status='processing' AND created_at<? AND closed_at IS NULL`).all(tableId, cutoff);
  for (const p of stale) {
    db.prepare(`UPDATE payments SET status='failed' WHERE id=?`).run(p.id);
    db.prepare('UPDATE order_items SET paid_payment_id=NULL WHERE paid_payment_id=?').run(p.id);
  }
}
function tabFor(tableId) {
  expireStalePayments(tableId);
  const all = db.prepare(`SELECT * FROM orders WHERE table_id=? AND closed_at IS NULL AND status!='cancelled' ORDER BY id`).all(tableId);
  for (const o of all) o.items = db.prepare('SELECT * FROM order_items WHERE order_id=? ORDER BY id').all(o.id);
  const sent = all.filter((o) => o.status === 'sent');
  let subtotal = 0;
  for (const o of sent) for (const i of o.items) if (i.status !== 'cancelled') subtotal += i.qty * i.unit_price_cents;
  const tax = Math.round((subtotal * taxPct()) / 100);
  const total = subtotal + tax;
  const pays = db.prepare(`SELECT * FROM payments WHERE table_id=? AND closed_at IS NULL AND status IN('paid','awaiting_staff','processing') ORDER BY id`).all(tableId);
  const paid = pays.reduce((s, p) => s + p.amount_cents, 0);
  return { orders: all, subtotal, tax, total, paid, remaining: Math.max(0, total - paid), payments: pays };
}
const grossOf = (cents) => Math.round(cents * (1 + taxPct() / 100));

function guestOrderView(o) {
  return { id: o.id, status: o.status, created_at: o.created_at, note: o.note, items: o.items.map((i) => ({ id: i.id, name: i.name, size: i.size, qty: i.qty, unit_price_cents: i.unit_price_cents, status: i.status, notes: i.notes, paid: !!i.paid_payment_id })) };
}
function publicSettings(s) {
  const methods = ['cash', 'bank_transfer'];
  if (payments.onlineEnabled()) methods.push('card', 'apple_pay', 'google_pay');
  return {
    restaurant_name: s.restaurant_name, currency: s.currency, locale: s.locale, tax_percent: Number(s.tax_percent) || 0,
    tip_presets: s.tip_presets.split(',').map(Number).filter((n) => Number.isFinite(n) && n >= 0 && n <= 100).slice(0, 6),
    wifi_ssid: s.wifi_ssid, wifi_password: s.wifi_password, review_url: s.review_url, methods, brand: BRAND,
  };
}
function sendReceiptEmail(paymentId) {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(paymentId);
  if (!p || !p.email) return;
  const s = getSettings();
  const link = `${baseUrl(null)}/r/${p.receipt_token}`;
  const subject = `Your receipt from ${s.restaurant_name}`;
  const html = `<p>Thank you for dining with ${U.esc(s.restaurant_name)}.</p><p>Your receipt: <a href="${U.esc(link)}">${U.esc(link)}</a></p>`;
  const id = db.prepare('INSERT INTO outbox(to_addr,subject,body_html,created_at) VALUES(?,?,?,?)').run(p.email, subject, html, now()).lastInsertRowid;
  payments.sendMail(db, Number(id)).catch(() => {});
}
function baseUrl(req) {
  const s = getSettings().base_url;
  if (s) return s.replace(/\/+$/, '');
  if (baseUrlEnv()) return baseUrlEnv();
  const host = req?.headers?.host || 'localhost:3000';
  return `http://${host}`;
}
function markPaid(paymentId, ref) {
  const done = tx(() => {
    const p = db.prepare('SELECT * FROM payments WHERE id=?').get(paymentId);
    if (!p || p.status === 'paid') return null;
    db.prepare(`UPDATE payments SET status='paid', paid_at=?, provider_ref=COALESCE(?,provider_ref) WHERE id=?`).run(now(), ref || null, paymentId);
    const pts = Math.floor((p.amount_cents / 100) * (Number(getSettings().points_per_unit) || 0));
    if (p.guest_id && pts > 0) addPoints(p.guest_id, pts, `Payment #${p.id}`);
    return p;
  });
  if (done) { sendReceiptEmail(paymentId); notifyTable(done.table_id); }
  return done;
}
const notifyStaff = () => U.publish('staff');
const notifyTable = (tid) => { U.publish('t' + tid); U.publish('staff'); };

function tableStatus(t, tab, calls) {
  if (calls.some((c) => c.status !== 'done' && c.kind !== 'bill')) return 'help';
  if (tab.orders.some((o) => o.status === 'placed')) return 'approve';
  if (calls.some((c) => c.status !== 'done' && c.kind === 'bill') || tab.payments.some((p) => p.status === 'awaiting_staff')) return 'bill';
  if (tab.total > 0 && tab.remaining === 0) return 'paid';
  if (tab.orders.some((o) => o.status === 'sent')) return 'busy';
  return 'free';
}

// ================================================================= PUBLIC / GUEST API
route('GET', '/api/health', () => ok({ time: now() }));

route('POST', '/api/leads', { limit: [5, 3600e3] }, (ctx) => {
  const b = ctx.body;
  db.prepare('INSERT INTO leads(name,email,restaurant,message,created_at) VALUES(?,?,?,?,?)').run(
    str(b.name, { min: 1, max: 100, name: 'name' }), email(b.email), str(b.restaurant ?? '', { max: 120, name: 'restaurant' }), str(b.message ?? '', { max: 1500, name: 'message' }), now());
  notifyStaff();
  return ok();
});

route('GET', '/api/t/:token/menu', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const guest = ensureGuest(ctx, table);
  const s = getSettings();
  const rewards = db.prepare('SELECT id,name,cost_points FROM rewards WHERE active=1 ORDER BY cost_points').all();
  return ok({ settings: publicSettings(s), table: { label: table.label }, ...menuData(), rewards, guest: { nickname: guest.nickname, points: guest.points }, allergens: ALLERGENS });
});

route('POST', '/api/t/:token/guest', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const nick = str(ctx.body.nickname, { min: 2, max: 20, name: 'nickname' });
  db.prepare('UPDATE guests SET nickname=? WHERE id=?').run(nick, g.id);
  return ok({ nickname: nick });
});

route('POST', '/api/t/:token/orders', { limit: [20, 600e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const guest = ensureGuest(ctx, table);
  const lines = ctx.body.items;
  if (!Array.isArray(lines) || lines.length < 1 || lines.length > 30) throw bad('Add between 1 and 30 items');
  const note = str(ctx.body.note ?? '', { max: 300, name: 'note' });
  const orderId = tx(() => {
    const pending = db.prepare(`SELECT COUNT(*) c FROM orders WHERE table_id=? AND status='placed' AND closed_at IS NULL`).get(table.id).c;
    if (pending >= 5) throw bad('Your earlier orders are still waiting for the staff. Please wait a moment.');
    const oid = Number(db.prepare(`INSERT INTO orders(table_id,guest_id,status,note,created_at) VALUES(?,?, 'placed',?,?)`).run(table.id, guest.id, note, now()).lastInsertRowid);
    const ins = db.prepare('INSERT INTO order_items(order_id,item_id,name,size,qty,unit_price_cents,notes,station,prep_minutes) VALUES(?,?,?,?,?,?,?,?,?)');
    for (const l of lines) {
      const it = db.prepare('SELECT * FROM items WHERE id=? AND available=1').get(int(l.id, { min: 1, name: 'item' }));
      if (!it) throw bad('One of the dishes is no longer available');
      const sizes = JSON.parse(it.sizes);
      let size = '', delta = 0;
      if (sizes.length) {
        size = str(l.size ?? '', { max: 40, name: 'size' });
        const found = sizes.find((x) => x.name === size);
        if (!found) throw bad(`Please choose a size for ${it.name}`);
        delta = found.delta_cents;
      }
      const qty = int(l.qty, { min: 1, max: 20, name: 'quantity' });
      const price = Math.max(0, effectivePrice(it) + delta);
      ins.run(oid, it.id, it.name, size, qty, price, str(l.notes ?? '', { max: 150, name: 'dish note' }), it.station, it.prep_minutes);
    }
    return oid;
  });
  notifyTable(table.id);
  return ok({ order_id: orderId });
});

route('GET', '/api/t/:token/tab', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const tab = tabFor(table.id);
  const calls = db.prepare(`SELECT id,kind,status,created_at FROM calls WHERE table_id=? AND status!='done' ORDER BY id`).all(table.id);
  return ok({
    orders: tab.orders.map(guestOrderView), subtotal: tab.subtotal, tax: tab.tax, total: tab.total, paid: tab.paid, remaining: tab.remaining,
    payments: tab.payments.map((p) => ({ id: p.id, amount_cents: p.amount_cents, tip_cents: p.tip_cents, method: p.method, status: p.status, receipt: p.status === 'paid' ? p.receipt_token : null })),
    calls,
  });
});

route('POST', '/api/t/:token/call', { limit: [15, 300e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const kind = oneOf(ctx.body.kind, CALL_KINDS, 'kind');
  const existing = db.prepare(`SELECT id FROM calls WHERE table_id=? AND kind=? AND status!='done'`).get(table.id, kind);
  if (!existing) db.prepare('INSERT INTO calls(table_id,kind,created_at,updated_at) VALUES(?,?,?,?)').run(table.id, kind, now(), now());
  notifyTable(table.id);
  return ok({ already: !!existing });
});

route('POST', '/api/t/:token/pay', { limit: [20, 600e3] }, async (ctx) => {
  const table = tableByToken(ctx.params.token);
  const guest = ensureGuest(ctx, table);
  const b = ctx.body;
  const s = publicSettings(getSettings());
  const method = oneOf(b.method, s.methods, 'payment method');
  const mode = oneOf(b.mode, ['equal', 'items', 'all'], 'mode');
  const mail = b.email ? email(b.email) : null;
  const created = tx(() => {
    const tab = tabFor(table.id);
    if (tab.total <= 0) throw bad('There is nothing to pay yet');
    if (tab.remaining <= 0) throw bad('This table is already fully paid');
    let amount, itemIds = [];
    if (mode === 'all') amount = tab.remaining;
    else if (mode === 'equal') {
      const parts = int(b.parts, { min: 1, max: 20, name: 'number of people' });
      amount = Math.min(tab.remaining, Math.ceil(tab.remaining / parts));
    } else {
      if (!Array.isArray(b.item_ids) || !b.item_ids.length || b.item_ids.length > 100) throw bad('Select at least one item');
      const sentItems = tab.orders.filter((o) => o.status === 'sent').flatMap((o) => o.items);
      let sub = 0;
      for (const id of b.item_ids) {
        const it = sentItems.find((x) => x.id === id && x.status !== 'cancelled');
        if (!it) throw bad('An item is not part of this bill');
        if (it.paid_payment_id) throw bad('An item was already paid');
        sub += it.qty * it.unit_price_cents; itemIds.push(it.id);
      }
      if (new Set(itemIds).size !== itemIds.length) throw bad('Duplicate item');
      amount = grossOf(sub);
      const unpaidAfter = sentItems.filter((x) => x.status !== 'cancelled' && !x.paid_payment_id && !itemIds.includes(x.id));
      if (!unpaidAfter.length || amount > tab.remaining) amount = tab.remaining;
    }
    if (amount < 1) throw bad('Amount too small');
    let tip = 0;
    if (b.tip_percent != null) tip = Math.round((amount * int(b.tip_percent, { min: 0, max: 100, name: 'tip' })) / 100);
    else if (b.tip_cents != null) tip = int(b.tip_cents, { min: 0, max: amount, name: 'tip' });
    const status = ['cash', 'bank_transfer'].includes(method) ? 'awaiting_staff' : 'processing';
    const rtoken = U.token(16);
    const pid = Number(db.prepare(`INSERT INTO payments(table_id,guest_id,amount_cents,tip_cents,method,status,email,receipt_token,created_at) VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(table.id, guest.id, amount, tip, method, status, mail, rtoken, now()).lastInsertRowid);
    for (const id of itemIds) db.prepare('UPDATE order_items SET paid_payment_id=? WHERE id=?').run(pid, id);
    if (status === 'awaiting_staff') {
      const exists = db.prepare(`SELECT id FROM calls WHERE table_id=? AND kind='bill' AND status!='done'`).get(table.id);
      if (!exists) db.prepare(`INSERT INTO calls(table_id,kind,created_at,updated_at) VALUES(?,?,?,?)`).run(table.id, 'bill', now(), now());
    }
    return { pid, amount, tip, status, rtoken };
  });
  notifyTable(table.id);
  if (created.status === 'awaiting_staff') return ok({ payment_id: created.pid, status: 'awaiting_staff', amount_cents: created.amount, tip_cents: created.tip });
  const r = await payments.startOnline({ paymentId: created.pid, amount: created.amount + created.tip, currency: getSettings().currency, label: `${getSettings().restaurant_name} - table ${table.label}`, method, base: baseUrl(ctx.req), token: ctx.params.token, email: mail });
  if (r.paidNow) { markPaid(created.pid, r.ref); return ok({ payment_id: created.pid, status: 'paid', amount_cents: created.amount, tip_cents: created.tip, receipt: created.rtoken }); }
  db.prepare('UPDATE payments SET provider_ref=? WHERE id=?').run(r.ref || null, created.pid);
  return ok({ payment_id: created.pid, status: 'processing', redirect: r.url });
});

route('POST', '/api/t/:token/review', { limit: [5, 3600e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  db.prepare('INSERT INTO reviews(table_id,rating,comment,created_at) VALUES(?,?,?,?)').run(table.id, int(ctx.body.rating, { min: 1, max: 5, name: 'rating' }), str(ctx.body.comment ?? '', { max: 600, name: 'comment' }), now());
  notifyStaff();
  return ok();
});

route('POST', '/api/t/:token/redeem', { limit: [10, 3600e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const code = tx(() => {
    const rw = db.prepare('SELECT * FROM rewards WHERE id=? AND active=1').get(int(ctx.body.reward_id, { min: 1, name: 'reward' }));
    if (!rw) throw bad('Reward not available');
    const cur = db.prepare('SELECT points FROM guests WHERE id=?').get(g.id).points;
    if (cur < rw.cost_points) throw bad('Not enough points yet');
    addPoints(g.id, -rw.cost_points, `Redeemed ${rw.name}`);
    const c = U.token(3).toUpperCase();
    db.prepare('INSERT INTO redemptions(guest_id,reward_id,reward_name,table_id,code,created_at) VALUES(?,?,?,?,?,?)').run(g.id, rw.id, rw.name, table.id, c, now());
    return c;
  });
  notifyStaff();
  return ok({ code, points: db.prepare('SELECT points FROM guests WHERE id=?').get(g.id).points });
});

route('GET', '/api/t/:token/me', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const reds = db.prepare('SELECT reward_name,code,status FROM redemptions WHERE guest_id=? ORDER BY id DESC LIMIT 10').all(g.id);
  return ok({ nickname: g.nickname, points: db.prepare('SELECT points FROM guests WHERE id=?').get(g.id).points, redemptions: reds });
});

// ---- quiz
route('GET', '/api/t/:token/quiz', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const answered = new Set(db.prepare('SELECT qid FROM quiz_answers WHERE guest_id=?').all(g.id).map((r) => r.qid));
  const left = QUIZ.map((q, i) => ({ q, i })).filter((x) => !answered.has(x.i));
  if (!left.length) return ok({ done: true });
  const pick = left[Math.floor(Math.random() * left.length)];
  return ok({ qid: pick.i, question: pick.q.q, options: pick.q.options });
});
route('POST', '/api/t/:token/quiz', { limit: [40, 600e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const qid = int(ctx.body.qid, { min: 0, max: QUIZ.length - 1, name: 'question' });
  const choice = int(ctx.body.choice, { min: 0, max: 5, name: 'choice' });
  const done = db.prepare('SELECT 1 FROM quiz_answers WHERE guest_id=? AND qid=?').get(g.id, qid);
  if (done) throw bad('Already answered');
  const correct = choice === QUIZ[qid].answer;
  const earned = db.prepare('SELECT COALESCE(SUM(delta),0) s FROM points_ledger WHERE guest_id=? AND reason=?').get(g.id, 'Quiz').s;
  db.prepare('INSERT INTO quiz_answers(guest_id,qid,correct,created_at) VALUES(?,?,?,?)').run(g.id, qid, correct ? 1 : 0, now());
  let gained = 0;
  if (correct && earned < 30) { gained = 5; addPoints(g.id, 5, 'Quiz'); }
  return ok({ correct, answer: QUIZ[qid].answer, gained, points: db.prepare('SELECT points FROM guests WHERE id=?').get(g.id).points });
});

// ---- tic-tac-toe lobby (works across tables)
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function gameView(g, me) {
  return { id: g.id, board: g.board, turn: g.turn, status: g.status, p1: g.p1_nick, p1_table: g.p1_table, p2: g.p2_nick, p2_table: g.p2_table, mine: me === g.p1 ? 'X' : me === g.p2 ? 'O' : null, winner: g.winner ? (g.winner === g.p1 ? 'X' : 'O') : null };
}
route('GET', '/api/t/:token/games', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  db.prepare(`UPDATE games SET status='abandoned' WHERE status IN('open','playing') AND updated_at<?`).run(now() - 15 * 60e3);
  const open = db.prepare(`SELECT * FROM games WHERE status='open' AND p1!=? ORDER BY id DESC LIMIT 10`).all(g.id);
  const mine = db.prepare(`SELECT * FROM games WHERE (p1=? OR p2=?) AND status IN('open','playing') ORDER BY id DESC LIMIT 1`).get(g.id, g.id)
    || db.prepare(`SELECT * FROM games WHERE (p1=? OR p2=?) AND status IN('won','draw') AND updated_at>? ORDER BY id DESC LIMIT 1`).get(g.id, g.id, now() - 60e3);
  return ok({ open: open.map((x) => gameView(x, g.id)), mine: mine ? gameView(mine, g.id) : null });
});
route('POST', '/api/t/:token/games', { limit: [20, 600e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const active = db.prepare(`SELECT id FROM games WHERE (p1=? OR p2=?) AND status IN('open','playing')`).get(g.id, g.id);
  if (active) throw bad('Finish your current game first');
  const id = db.prepare('INSERT INTO games(p1,p1_nick,p1_table,created_at,updated_at) VALUES(?,?,?,?,?)').run(g.id, g.nickname, table.label, now(), now()).lastInsertRowid;
  U.publish('games');
  return ok({ id: Number(id) });
});
route('POST', '/api/t/:token/games/:id/join', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const gm = db.prepare('SELECT * FROM games WHERE id=?').get(Number(ctx.params.id));
  if (!gm || gm.status !== 'open') throw bad('That game is no longer open');
  if (gm.p1 === g.id) throw bad('You cannot join your own game');
  const active = db.prepare(`SELECT id FROM games WHERE (p1=? OR p2=?) AND status IN('open','playing')`).get(g.id, g.id);
  if (active) throw bad('Finish your current game first');
  db.prepare(`UPDATE games SET p2=?,p2_nick=?,p2_table=?,status='playing',updated_at=? WHERE id=?`).run(g.id, g.nickname, table.label, now(), gm.id);
  U.publish('games');
  return ok();
});
route('POST', '/api/t/:token/games/:id/move', { limit: [120, 60e3] }, (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  const cell = int(ctx.body.cell, { min: 0, max: 8, name: 'cell' });
  const res = tx(() => {
    const gm = db.prepare('SELECT * FROM games WHERE id=?').get(Number(ctx.params.id));
    if (!gm || gm.status !== 'playing') throw bad('Game is not in progress');
    const mark = g.id === gm.p1 ? 'X' : g.id === gm.p2 ? 'O' : null;
    if (!mark) throw new HttpError(403, 'You are not in this game');
    if (gm.turn !== mark) throw bad('Not your turn');
    if (gm.board[cell] !== '-') throw bad('That square is taken');
    const board = gm.board.slice(0, cell) + mark + gm.board.slice(cell + 1);
    const won = LINES.some((l) => l.every((i) => board[i] === mark));
    const full = !board.includes('-');
    const status = won ? 'won' : full ? 'draw' : 'playing';
    db.prepare('UPDATE games SET board=?,turn=?,status=?,winner=?,updated_at=? WHERE id=?').run(board, mark === 'X' ? 'O' : 'X', status, won ? g.id : null, now(), gm.id);
    if (won) addPoints(g.id, 10, 'Game win');
    if (full && !won) { addPoints(gm.p1, 3, 'Game draw'); addPoints(gm.p2, 3, 'Game draw'); }
    return status;
  });
  U.publish('games');
  return ok({ status: res });
});
route('POST', '/api/t/:token/games/:id/leave', (ctx) => {
  const table = tableByToken(ctx.params.token);
  const g = ensureGuest(ctx, table);
  db.prepare(`UPDATE games SET status='abandoned',updated_at=? WHERE id=? AND (p1=? OR p2=?) AND status IN('open','playing')`).run(now(), Number(ctx.params.id), g.id, g.id);
  U.publish('games');
  return ok();
});

route('GET', '/api/t/:token/stream', (ctx) => {
  const table = tableByToken(ctx.params.token);
  U.subscribe(['t' + table.id, 'games'], ctx.req, ctx.res, ctx.ip);
  ctx.streamed = true;
});

// ---- receipts (public, unguessable link)
route('GET', '/r/:token', (ctx) => {
  if (!/^[a-f0-9]{32}$/.test(ctx.params.token)) throw new HttpError(404, 'Receipt not found');
  const p = db.prepare(`SELECT p.*, t.label FROM payments p JOIN dining_tables t ON t.id=p.table_id WHERE receipt_token=? AND status='paid'`).get(ctx.params.token);
  if (!p) throw new HttpError(404, 'Receipt not found');
  const s = getSettings();
  const fmt = new Intl.NumberFormat(s.locale, { style: 'currency', currency: s.currency });
  const m = (c) => fmt.format(c / 100);
  const items = db.prepare('SELECT name,size,qty,unit_price_cents FROM order_items WHERE paid_payment_id=?').all(p.id);
  const rows = items.map((i) => `<tr><td>${U.esc(i.qty)} × ${U.esc(i.name)}${i.size ? ' (' + U.esc(i.size) + ')' : ''}</td><td class="r">${m(i.qty * i.unit_price_cents)}</td></tr>`).join('');
  ctx.html(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Receipt – ${U.esc(s.restaurant_name)}</title><link rel="stylesheet" href="/css/app.css"></head>
<body class="receipt"><main class="card receipt-card"><h1>${U.esc(s.restaurant_name)}</h1><p class="muted">Receipt #${p.id} · Table ${U.esc(p.label)} · ${U.esc(new Date(p.paid_at).toLocaleString(s.locale))}</p>
<table class="rtable">${rows || ''}<tr><td>Bill amount (incl. tax)</td><td class="r">${m(p.amount_cents)}</td></tr><tr><td>Tip</td><td class="r">${m(p.tip_cents)}</td></tr><tr class="total"><td>Total paid</td><td class="r">${m(p.amount_cents + p.tip_cents)}</td></tr></table>
<p class="muted">Paid by ${U.esc(p.method.replace('_', ' '))}. Thank you!</p></main></body></html>`);
});

// ================================================================= AUTH
route('POST', '/api/auth/login', async (ctx) => {
  const em = String(ctx.body.email || '').toLowerCase().slice(0, 254);
  const pw = typeof ctx.body.password === 'string' ? ctx.body.password.slice(0, 200) : '';
  if (!U.rateLimit('login-ip:' + ctx.ip, 20, 15 * 60e3) || !U.rateLimit('login-em:' + em, 8, 15 * 60e3)) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
  const u = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(em);
  const valid = U.verifyPassword(pw, u ? u.pass_hash : U.DUMMY_HASH) && !!u;
  if (!valid) throw new HttpError(401, 'Incorrect email or password');
  const sid = U.token(24);
  db.prepare('INSERT INTO sessions(id,user_id,expires_at) VALUES(?,?,?)').run(U.sha256(sid), u.id, now() + 12 * 3600e3);
  db.prepare('DELETE FROM sessions WHERE expires_at<?').run(now());
  setCookie(ctx.res, 'sid', sid, 12 * 3600);
  return ok({ user: { name: u.name, role: u.role } });
});
route('POST', '/api/auth/logout', (ctx) => {
  const sid = U.parseCookies(ctx.req.headers.cookie).sid;
  if (sid) db.prepare('DELETE FROM sessions WHERE id=?').run(U.sha256(sid));
  setCookie(ctx.res, 'sid', '', 0);
  return ok();
});
route('GET', '/api/auth/me', (ctx) => { need(ctx); return ok({ user: ctx.user, settings: publicSettings(getSettings()) }); });
route('POST', '/api/auth/password', (ctx) => {
  need(ctx);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(ctx.user.id);
  if (!U.verifyPassword(String(ctx.body.current || ''), u.pass_hash)) throw new HttpError(403, 'Current password is incorrect');
  U.checkPasswordStrength(ctx.body.next);
  db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(U.hashPassword(ctx.body.next), u.id);
  const sid = U.parseCookies(ctx.req.headers.cookie).sid;
  db.prepare('DELETE FROM sessions WHERE user_id=? AND id!=?').run(u.id, U.sha256(sid));
  return ok();
});

// ================================================================= STAFF API
function floorState() {
  const s = getSettings();
  const tables = db.prepare('SELECT * FROM dining_tables WHERE active=1 ORDER BY id').all().map((t) => {
    const tab = tabFor(t.id);
    const calls = db.prepare(`SELECT id,kind,status,created_at FROM calls WHERE table_id=? AND status!='done' ORDER BY id`).all(t.id);
    const first = tab.orders[0]?.created_at ?? null;
    return { id: t.id, label: t.label, seats: t.seats, x: t.x, y: t.y, status: tableStatus(t, tab, calls), total: tab.total, remaining: tab.remaining, since: first, calls };
  });
  const orders = db.prepare(`SELECT o.*, t.label table_label FROM orders o JOIN dining_tables t ON t.id=o.table_id WHERE o.closed_at IS NULL AND o.status IN('placed','sent') ORDER BY o.id`).all();
  for (const o of orders) o.items = db.prepare('SELECT * FROM order_items WHERE order_id=? ORDER BY id').all(o.id);
  const callsAll = db.prepare(`SELECT c.*, t.label table_label FROM calls c JOIN dining_tables t ON t.id=c.table_id WHERE c.status!='done' ORDER BY c.id`).all();
  const pend = db.prepare(`SELECT p.*, t.label table_label FROM payments p JOIN dining_tables t ON t.id=p.table_id WHERE p.status='awaiting_staff' AND p.closed_at IS NULL ORDER BY p.id`).all();
  const reds = db.prepare(`SELECT r.*, t.label table_label FROM redemptions r JOIN dining_tables t ON t.id=r.table_id WHERE r.status='pending' ORDER BY r.id`).all();
  return { now: now(), settings: publicSettings(s), tables, orders, calls: callsAll, pending_payments: pend, redemptions: reds };
}
route('GET', '/api/staff/state', (ctx) => { need(ctx, 'waiter', 'admin'); return ok(floorState()); });
route('GET', '/api/kitchen/state', (ctx) => {
  need(ctx, 'kitchen', 'waiter', 'admin');
  const orders = db.prepare(`SELECT o.id,o.note,o.sent_at,t.label table_label FROM orders o JOIN dining_tables t ON t.id=o.table_id WHERE o.closed_at IS NULL AND o.status='sent' ORDER BY o.sent_at`).all();
  for (const o of orders) o.items = db.prepare(`SELECT id,name,size,qty,notes,station,prep_minutes,status,started_at,ready_at FROM order_items WHERE order_id=? AND status!='cancelled' ORDER BY id`).all(o.id);
  return ok({ now: now(), orders: orders.filter((o) => o.items.some((i) => i.status !== 'served')), stations: STATIONS });
});
route('GET', '/api/staff/stream', (ctx) => { need(ctx, 'kitchen', 'waiter', 'admin'); U.subscribe('staff', ctx.req, ctx.res, ctx.ip); ctx.streamed = true; });

route('POST', '/api/staff/orders/:id/send', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const r = db.prepare(`UPDATE orders SET status='sent', sent_at=? WHERE id=? AND status='placed' AND closed_at IS NULL`).run(now(), Number(ctx.params.id));
  if (!r.changes) throw bad('Order is not waiting for approval');
  const o = db.prepare('SELECT table_id FROM orders WHERE id=?').get(Number(ctx.params.id));
  notifyTable(o.table_id);
  return ok();
});
route('POST', '/api/staff/orders/:id/reject', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const r = db.prepare(`UPDATE orders SET status='cancelled' WHERE id=? AND status='placed' AND closed_at IS NULL`).run(Number(ctx.params.id));
  if (!r.changes) throw bad('Only orders waiting for approval can be rejected');
  const o = db.prepare('SELECT table_id FROM orders WHERE id=?').get(Number(ctx.params.id));
  notifyTable(o.table_id);
  return ok();
});
const NEXT = { new: ['preparing', 'ready'], preparing: ['ready', 'new'], ready: ['served', 'preparing'], served: [] };
route('POST', '/api/staff/items/status', (ctx) => {
  need(ctx, 'kitchen', 'waiter', 'admin');
  const status = oneOf(ctx.body.status, ['new', 'preparing', 'ready', 'served'], 'status');
  if (!Array.isArray(ctx.body.ids) || !ctx.body.ids.length || ctx.body.ids.length > 100) throw bad('No items selected');
  if (status === 'served' && ctx.user.role === 'kitchen') throw new HttpError(403, 'Only floor staff can mark items served');
  let changed = 0; const tables = new Set();
  tx(() => {
    for (const id of ctx.body.ids) {
      const it = db.prepare(`SELECT i.*, o.status ostatus, o.table_id FROM order_items i JOIN orders o ON o.id=i.order_id WHERE i.id=? AND o.closed_at IS NULL`).get(int(id, { min: 1, name: 'item' }));
      if (!it || it.ostatus !== 'sent' || !(NEXT[it.status] || []).includes(status)) continue;
      const t = now();
      db.prepare('UPDATE order_items SET status=?, started_at=CASE WHEN ?=\'preparing\' THEN COALESCE(started_at,?) WHEN ?=\'new\' THEN NULL ELSE started_at END, ready_at=CASE WHEN ?=\'ready\' THEN ? WHEN ? IN(\'new\',\'preparing\') THEN NULL ELSE ready_at END WHERE id=?').run(status, status, t, status, status, t, status, it.id);
      changed++; tables.add(it.table_id);
    }
  });
  for (const t of tables) notifyTable(t);
  return ok({ changed });
});
route('POST', '/api/staff/calls/:id', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const status = oneOf(ctx.body.status, ['ack', 'done'], 'status');
  const c = db.prepare('SELECT * FROM calls WHERE id=?').get(Number(ctx.params.id));
  if (!c) throw new HttpError(404, 'Not found');
  db.prepare('UPDATE calls SET status=?, updated_at=? WHERE id=?').run(status, now(), c.id);
  notifyTable(c.table_id);
  return ok();
});
route('POST', '/api/staff/payments/:id/confirm', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const p = db.prepare(`SELECT * FROM payments WHERE id=? AND status='awaiting_staff' AND closed_at IS NULL`).get(Number(ctx.params.id));
  if (!p) throw bad('Payment is not waiting for confirmation');
  markPaid(p.id, null);
  const left = db.prepare(`SELECT COUNT(*) c FROM payments WHERE table_id=? AND status='awaiting_staff' AND closed_at IS NULL`).get(p.table_id).c;
  if (!left) db.prepare(`UPDATE calls SET status='done', updated_at=? WHERE table_id=? AND kind='bill' AND status!='done'`).run(now(), p.table_id);
  audit(ctx, 'payment.confirm', `#${p.id} ${p.method}`);
  return ok();
});
route('POST', '/api/staff/payments/:id/reject', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const p = db.prepare(`SELECT * FROM payments WHERE id=? AND status='awaiting_staff' AND closed_at IS NULL`).get(Number(ctx.params.id));
  if (!p) throw bad('Payment is not waiting for confirmation');
  db.prepare(`UPDATE payments SET status='cancelled' WHERE id=?`).run(p.id);
  db.prepare('UPDATE order_items SET paid_payment_id=NULL WHERE paid_payment_id=?').run(p.id);
  audit(ctx, 'payment.reject', `#${p.id}`);
  notifyTable(p.table_id);
  return ok();
});
route('POST', '/api/staff/tables/:id/close', (ctx) => {
  need(ctx, 'waiter', 'admin');
  const tid = Number(ctx.params.id);
  const t = db.prepare('SELECT * FROM dining_tables WHERE id=?').get(tid);
  if (!t) throw new HttpError(404, 'Table not found');
  const tab = tabFor(tid);
  const force = ctx.body.force === true;
  if (tab.remaining > 0 && !(force && ctx.user.role === 'admin')) throw bad(tab.total ? 'The bill is not fully paid yet' : 'Nothing to close');
  tx(() => {
    const ts = now();
    db.prepare('UPDATE orders SET closed_at=? WHERE table_id=? AND closed_at IS NULL').run(ts, tid);
    db.prepare('UPDATE payments SET closed_at=? WHERE table_id=? AND closed_at IS NULL').run(ts, tid);
    db.prepare(`UPDATE calls SET status='done', updated_at=? WHERE table_id=? AND status!='done'`).run(ts, tid);
  });
  audit(ctx, 'table.close', `${t.label}${force ? ' (forced)' : ''}`);
  notifyTable(tid);
  return ok();
});
route('POST', '/api/staff/redemptions/:id/fulfil', (ctx) => {
  need(ctx, 'waiter', 'admin');
  db.prepare(`UPDATE redemptions SET status='fulfilled' WHERE id=?`).run(Number(ctx.params.id));
  notifyStaff();
  return ok();
});

// ================================================================= ADMIN API
const ADMIN = (ctx) => need(ctx, 'admin');
function validItem(b) {
  const sizes = Array.isArray(b.sizes) ? b.sizes : [];
  if (sizes.length > 6) throw bad('At most 6 sizes');
  return {
    category_id: int(b.category_id, { min: 1, name: 'category' }),
    name: str(b.name, { min: 1, max: 80, name: 'name' }),
    description: str(b.description ?? '', { max: 300, name: 'description' }),
    price_cents: int(b.price_cents, { min: 0, max: 100000000, name: 'price' }),
    diet: oneOf(b.diet, DIETS, 'diet'),
    spice: int(b.spice ?? 0, { min: 0, max: 3, name: 'spice level' }),
    sizes: JSON.stringify(sizes.map((x) => ({ name: str(x.name, { min: 1, max: 40, name: 'size name' }), delta_cents: int(x.delta_cents, { min: -100000000, max: 100000000, name: 'size price change' }) }))),
    allergens: JSON.stringify(strList(b.allergens, ALLERGENS, 'allergens')),
    station: oneOf(b.station, STATIONS, 'station'),
    prep_minutes: int(b.prep_minutes ?? 10, { min: 1, max: 180, name: 'prep time' }),
    available: b.available === false ? 0 : 1,
    emoji: str(b.emoji ?? '🍽️', { min: 1, max: 8, name: 'emoji' }),
  };
}
route('GET', '/api/admin/menu', (ctx) => {
  ADMIN(ctx);
  return ok({
    categories: db.prepare('SELECT * FROM categories ORDER BY sort,id').all(),
    items: db.prepare('SELECT * FROM items ORDER BY category_id,sort,id').all().map(parseItem),
    deals: db.prepare('SELECT * FROM deals ORDER BY id').all(),
    rewards: db.prepare('SELECT * FROM rewards ORDER BY cost_points').all(),
    allergens: ALLERGENS, stations: STATIONS, diets: DIETS,
  });
});
route('POST', '/api/admin/categories', (ctx) => { ADMIN(ctx); const id = db.prepare('INSERT INTO categories(name,sort) VALUES(?,?)').run(str(ctx.body.name, { min: 1, max: 60, name: 'name' }), int(ctx.body.sort ?? 0, { min: 0, max: 999 })).lastInsertRowid; return ok({ id: Number(id) }); });
route('PUT', '/api/admin/categories/:id', (ctx) => { ADMIN(ctx); db.prepare('UPDATE categories SET name=?, sort=? WHERE id=?').run(str(ctx.body.name, { min: 1, max: 60, name: 'name' }), int(ctx.body.sort ?? 0, { min: 0, max: 999 }), Number(ctx.params.id)); return ok(); });
route('DELETE', '/api/admin/categories/:id', (ctx) => { ADMIN(ctx); db.prepare('DELETE FROM categories WHERE id=?').run(Number(ctx.params.id)); audit(ctx, 'category.delete', ctx.params.id); return ok(); });
route('POST', '/api/admin/items', (ctx) => {
  ADMIN(ctx);
  const v = validItem(ctx.body);
  if (!db.prepare('SELECT 1 FROM categories WHERE id=?').get(v.category_id)) throw bad('Category not found');
  const id = db.prepare(`INSERT INTO items(category_id,name,description,price_cents,diet,spice,sizes,allergens,station,prep_minutes,available,emoji) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(v.category_id, v.name, v.description, v.price_cents, v.diet, v.spice, v.sizes, v.allergens, v.station, v.prep_minutes, v.available, v.emoji).lastInsertRowid;
  return ok({ id: Number(id) });
});
route('PUT', '/api/admin/items/:id', (ctx) => {
  ADMIN(ctx);
  const v = validItem(ctx.body);
  db.prepare(`UPDATE items SET category_id=?,name=?,description=?,price_cents=?,diet=?,spice=?,sizes=?,allergens=?,station=?,prep_minutes=?,available=?,emoji=? WHERE id=?`)
    .run(v.category_id, v.name, v.description, v.price_cents, v.diet, v.spice, v.sizes, v.allergens, v.station, v.prep_minutes, v.available, v.emoji, Number(ctx.params.id));
  return ok();
});
route('DELETE', '/api/admin/items/:id', (ctx) => { ADMIN(ctx); db.prepare('DELETE FROM items WHERE id=?').run(Number(ctx.params.id)); audit(ctx, 'item.delete', ctx.params.id); return ok(); });
route('POST', '/api/admin/deals', (ctx) => {
  ADMIN(ctx);
  const b = ctx.body;
  const item = b.item_id ? int(b.item_id, { min: 1 }) : null;
  const dp = item && b.deal_price_cents != null ? int(b.deal_price_cents, { min: 0, max: 100000000, name: 'deal price' }) : null;
  const id = db.prepare('INSERT INTO deals(title,description,item_id,deal_price_cents,active) VALUES(?,?,?,?,?)').run(str(b.title, { min: 1, max: 80, name: 'title' }), str(b.description ?? '', { max: 250 }), item, dp, b.active === false ? 0 : 1).lastInsertRowid;
  return ok({ id: Number(id) });
});
route('PUT', '/api/admin/deals/:id', (ctx) => {
  ADMIN(ctx);
  const b = ctx.body;
  const item = b.item_id ? int(b.item_id, { min: 1 }) : null;
  const dp = item && b.deal_price_cents != null ? int(b.deal_price_cents, { min: 0, max: 100000000, name: 'deal price' }) : null;
  db.prepare('UPDATE deals SET title=?,description=?,item_id=?,deal_price_cents=?,active=? WHERE id=?').run(str(b.title, { min: 1, max: 80, name: 'title' }), str(b.description ?? '', { max: 250 }), item, dp, b.active === false ? 0 : 1, Number(ctx.params.id));
  return ok();
});
route('DELETE', '/api/admin/deals/:id', (ctx) => { ADMIN(ctx); db.prepare('DELETE FROM deals WHERE id=?').run(Number(ctx.params.id)); return ok(); });
route('POST', '/api/admin/rewards', (ctx) => { ADMIN(ctx); const id = db.prepare('INSERT INTO rewards(name,cost_points) VALUES(?,?)').run(str(ctx.body.name, { min: 1, max: 80, name: 'name' }), int(ctx.body.cost_points, { min: 1, max: 100000, name: 'points' })).lastInsertRowid; return ok({ id: Number(id) }); });
route('DELETE', '/api/admin/rewards/:id', (ctx) => { ADMIN(ctx); db.prepare('UPDATE rewards SET active=0 WHERE id=?').run(Number(ctx.params.id)); return ok(); });

route('GET', '/api/admin/tables', (ctx) => {
  ADMIN(ctx);
  return ok({ tables: db.prepare('SELECT id,label,token,seats,x,y,active FROM dining_tables ORDER BY id').all(), base_url: baseUrl(ctx.req) });
});
route('POST', '/api/admin/tables', (ctx) => {
  ADMIN(ctx);
  const label = str(ctx.body.label, { min: 1, max: 12, name: 'label' });
  try {
    const id = db.prepare('INSERT INTO dining_tables(label,token,seats,x,y) VALUES(?,?,?,?,?)').run(label, U.token(16), int(ctx.body.seats ?? 4, { min: 1, max: 30, name: 'seats' }), 50, 50).lastInsertRowid;
    notifyStaff(); return ok({ id: Number(id) });
  } catch (e) { if (/UNIQUE/.test(e.message)) throw bad('A table with that label already exists'); throw e; }
});
route('PUT', '/api/admin/tables/:id', (ctx) => {
  ADMIN(ctx);
  const b = ctx.body;
  const x = Number(b.x), y = Number(b.y);
  if (!(x >= 0 && x <= 100 && y >= 0 && y <= 100)) throw bad('Position must be between 0 and 100');
  try { db.prepare('UPDATE dining_tables SET label=?,seats=?,x=?,y=?,active=? WHERE id=?').run(str(b.label, { min: 1, max: 12, name: 'label' }), int(b.seats, { min: 1, max: 30, name: 'seats' }), x, y, b.active === false ? 0 : 1, Number(ctx.params.id)); }
  catch (e) { if (/UNIQUE/.test(e.message)) throw bad('A table with that label already exists'); throw e; }
  notifyStaff(); return ok();
});
route('POST', '/api/admin/tables/:id/rotate', (ctx) => { ADMIN(ctx); db.prepare('UPDATE dining_tables SET token=? WHERE id=?').run(U.token(16), Number(ctx.params.id)); audit(ctx, 'table.rotate', ctx.params.id); return ok(); });
route('GET', '/api/admin/tables/:id/qr.svg', (ctx) => {
  ADMIN(ctx);
  const t = db.prepare('SELECT token FROM dining_tables WHERE id=?').get(Number(ctx.params.id));
  if (!t) throw new HttpError(404, 'Table not found');
  ctx.raw(200, 'image/svg+xml', qrSvg(`${baseUrl(ctx.req)}/t/${t.token}`));
});

route('GET', '/api/admin/users', (ctx) => { ADMIN(ctx); return ok({ users: db.prepare('SELECT id,email,name,role,active FROM users ORDER BY id').all() }); });
route('POST', '/api/admin/users', (ctx) => {
  ADMIN(ctx);
  U.checkPasswordStrength(ctx.body.password);
  try {
    const id = db.prepare('INSERT INTO users(email,name,pass_hash,role,created_at) VALUES(?,?,?,?,?)').run(email(ctx.body.email), str(ctx.body.name, { min: 1, max: 80, name: 'name' }), U.hashPassword(ctx.body.password), oneOf(ctx.body.role, ['admin', 'waiter', 'kitchen'], 'role'), now()).lastInsertRowid;
    audit(ctx, 'user.create', ctx.body.email); return ok({ id: Number(id) });
  } catch (e) { if (/UNIQUE/.test(e.message)) throw bad('That email is already used'); throw e; }
});
route('PUT', '/api/admin/users/:id', (ctx) => {
  ADMIN(ctx);
  const id = Number(ctx.params.id);
  const active = ctx.body.active === false ? 0 : 1;
  if (id === ctx.user.id && !active) throw bad('You cannot deactivate yourself');
  db.prepare('UPDATE users SET active=? WHERE id=?').run(active, id);
  if (!active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
  if (ctx.body.password) { U.checkPasswordStrength(ctx.body.password); db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(U.hashPassword(ctx.body.password), id); db.prepare('DELETE FROM sessions WHERE user_id=?').run(id); }
  audit(ctx, 'user.update', id); return ok();
});

route('GET', '/api/admin/settings', (ctx) => { ADMIN(ctx); return ok({ settings: getSettings(), payments: payments.status(), base_url_detected: baseUrl(ctx.req) }); });
route('PUT', '/api/admin/settings', (ctx) => {
  ADMIN(ctx);
  const b = ctx.body;
  const set = {
    restaurant_name: str(b.restaurant_name, { min: 1, max: 80, name: 'restaurant name' }),
    currency: str(b.currency, { min: 3, max: 3, name: 'currency' }).toUpperCase(),
    tax_percent: String(int(Number(b.tax_percent), { min: 0, max: 50, name: 'tax percent' })),
    tip_presets: String(b.tip_presets ?? '').split(',').map((x) => int(Number(x.trim()), { min: 0, max: 100, name: 'tip option' })).slice(0, 6).join(','),
    wifi_ssid: str(b.wifi_ssid ?? '', { max: 60, name: 'Wi-Fi name' }),
    wifi_password: str(b.wifi_password ?? '', { max: 80, name: 'Wi-Fi password' }),
    review_url: b.review_url ? str(b.review_url, { max: 300, name: 'review link' }) : '',
    base_url: b.base_url ? str(b.base_url, { max: 200, name: 'public URL' }).replace(/\/+$/, '') : '',
    points_per_unit: String(int(Number(b.points_per_unit ?? 1), { min: 0, max: 100, name: 'points per currency unit' })),
  };
  if (set.review_url && !/^https:\/\//.test(set.review_url)) throw bad('Review link must start with https://');
  if (set.base_url && !/^https?:\/\/[^\s]+$/.test(set.base_url)) throw bad('Public URL must start with http:// or https://');
  if (!Intl.supportedValuesOf('currency').includes(set.currency)) throw bad('Unknown currency code');
  for (const [k, v] of Object.entries(set)) setSetting(k, v);
  audit(ctx, 'settings.update'); return ok();
});
route('GET', '/api/admin/overview', (ctx) => {
  ADMIN(ctx);
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const t0 = day.getTime();
  const sales = db.prepare(`SELECT COUNT(*) n, COALESCE(SUM(amount_cents),0) amount, COALESCE(SUM(tip_cents),0) tips FROM payments WHERE status='paid' AND paid_at>=?`).get(t0);
  const byMethod = db.prepare(`SELECT method, SUM(amount_cents+tip_cents) total FROM payments WHERE status='paid' AND paid_at>=? GROUP BY method`).all(t0);
  const top = db.prepare(`SELECT oi.name, SUM(oi.qty) qty FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='sent' AND o.sent_at>=? AND oi.status!='cancelled' GROUP BY oi.name ORDER BY qty DESC LIMIT 5`).all(now() - 7 * 86400e3);
  const rating = db.prepare('SELECT ROUND(AVG(rating),2) avg, COUNT(*) n FROM reviews').get();
  const reviews = db.prepare('SELECT r.rating,r.comment,r.created_at,t.label FROM reviews r LEFT JOIN dining_tables t ON t.id=r.table_id ORDER BY r.id DESC LIMIT 20').all();
  const leads = db.prepare('SELECT * FROM leads ORDER BY id DESC LIMIT 30').all();
  const log = db.prepare('SELECT a.action,a.detail,a.created_at,u.name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 20').all();
  return ok({ sales, byMethod, top, rating, reviews, leads, log, payments: payments.status() });
});

// ---- Stripe webhook (raw body needed for signature verification)
route('POST', '/api/webhooks/stripe', { raw: true, noOrigin: true }, (ctx) => {
  const ev = payments.verifyStripeWebhook(ctx.rawBody, ctx.req.headers['stripe-signature']);
  if (ev.type === 'checkout.session.completed') {
    const sess = ev.data.object;
    const pid = Number(sess.metadata?.payment_id);
    const p = pid ? db.prepare('SELECT * FROM payments WHERE id=?').get(pid) : null;
    if (p && sess.payment_status === 'paid' && sess.amount_total === p.amount_cents + p.tip_cents && sess.currency.toUpperCase() === getSettings().currency) markPaid(pid, sess.payment_intent || sess.id);
  } else if (ev.type === 'checkout.session.expired') {
    const pid = Number(ev.data.object.metadata?.payment_id);
    if (pid) { db.prepare(`UPDATE payments SET status='failed' WHERE id=? AND status='processing'`).run(pid); db.prepare('UPDATE order_items SET paid_payment_id=NULL WHERE paid_payment_id=?').run(pid); }
  }
  return ok();
});

// ================================================================= HTTP SERVER
const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(self)',
  'Cross-Origin-Opener-Policy': 'same-origin',
};
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
const PAGES = { '/': 'index.html', '/login': 'login.html', '/kitchen': 'kitchen.html', '/floor': 'floor.html', '/admin': 'admin.html' };

function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || 'unknown';
}
function readBody(req, max) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > max) { if (n - c.length <= max) reject(new HttpError(413, 'Request too large')); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function template(html, req) {
  const base = baseUrl(req);
  const demo = process.env.DEMO_MODE === '1' ? db.prepare('SELECT token FROM dining_tables WHERE active=1 ORDER BY id LIMIT 1').get() : null;
  return html.replace(/\{\{BRAND\}\}/g, U.esc(BRAND)).replace(/\{\{BASE_URL\}\}/g, U.esc(base)).replace(/\{\{DEMO_URL\}\}/g, demo ? `/t/${demo.token}` : '/login');
}

async function handler(req, res) {
  const ip = clientIp(req);
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
  if (secureCookies() || req.headers['x-forwarded-proto'] === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  const ctx = { req, res, ip, query: Object.fromEntries(url.searchParams), params: {}, body: {}, user: null };
  ctx.raw = (status, type, body, extra = {}) => { res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', ...extra }); res.end(body); ctx.done = true; };
  ctx.html = (body) => ctx.raw(200, 'text/html; charset=utf-8', body);
  try {
    if (pathname.startsWith('/api/') || pathname.startsWith('/r/')) {
      let match = null;
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(pathname);
        if (m) { match = { r, m }; break; }
      }
      if (!match) {
        if (routes.some((r) => r.re.test(pathname))) throw new HttpError(405, 'Method not allowed');
        throw new HttpError(404, 'Not found');
      }
      const { r, m } = match;
      r.keys.forEach((k, i) => { ctx.params[k] = decodeURIComponent(m[i + 1]); });
      if (!U.rateLimit('g:' + ip, 600, 60e3)) throw new HttpError(429, 'Too many requests');
      if (r.opts.limit && !U.rateLimit(`${pathname.replace(/\d+/g, '#')}:${ip}`, r.opts.limit[0], r.opts.limit[1])) throw new HttpError(429, 'Too many requests. Please slow down.');
      ctx.user = userFromReq(req);
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        const origin = req.headers.origin;
        if (!r.opts.noOrigin && origin) {
          let oh; try { oh = new URL(origin).host; } catch { oh = ''; }
          if (oh !== req.headers.host) throw new HttpError(403, 'Cross-site request blocked');
        }
        if (r.opts.raw) ctx.rawBody = (await readBody(req, 262144)).toString('utf8');
        else {
          const buf = await readBody(req, 65536);
          if (buf.length) {
            if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'Content-Type must be application/json');
            try { ctx.body = JSON.parse(buf.toString('utf8')); } catch { throw bad('Invalid JSON'); }
            if (ctx.body === null || typeof ctx.body !== 'object' || Array.isArray(ctx.body)) throw bad('Body must be a JSON object');
          }
        }
      }
      const result = await r.handler(ctx);
      if (ctx.done || ctx.streamed) return;
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify(result ?? ok()));
    }
    // ----- pages & static files
    if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
    let file = null, isPage = false;
    if (PAGES[pathname]) { file = PAGES[pathname]; isPage = true; }
    else if (/^\/t\/[a-f0-9]{32}$/.test(pathname)) { file = 'guest.html'; isPage = true; }
    else if (pathname === '/robots.txt') {
      return ctx.raw(200, 'text/plain; charset=utf-8', `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /floor\nDisallow: /kitchen\nDisallow: /login\nDisallow: /t/\nDisallow: /r/\nSitemap: ${baseUrl(req)}/sitemap.xml\n`, { 'Cache-Control': 'public, max-age=3600' });
    } else if (pathname === '/sitemap.xml') {
      return ctx.raw(200, 'application/xml; charset=utf-8', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${U.esc(baseUrl(req))}/</loc><changefreq>monthly</changefreq><priority>1.0</priority></url></urlset>\n`, { 'Cache-Control': 'public, max-age=3600' });
    } else {
      const safe = path.normalize(decodeURIComponent(pathname)).replace(/^(\.\.[/\\])+/, '');
      const full = path.join(PUBLIC_DIR, safe);
      if (!full.startsWith(PUBLIC_DIR + path.sep) || /\.html$/.test(full)) throw new HttpError(404, 'Not found');
      file = path.relative(PUBLIC_DIR, full);
    }
    const full = path.join(PUBLIC_DIR, file);
    let stat; try { stat = fs.statSync(full); } catch { throw new HttpError(404, 'Not found'); }
    if (!stat.isFile()) throw new HttpError(404, 'Not found');
    const ext = path.extname(full);
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream' };
    if (isPage) {
      headers['Cache-Control'] = 'no-cache';
      if (/^\/(admin|floor|kitchen|login)$/.test(pathname) || pathname.startsWith('/t/')) headers['X-Robots-Tag'] = 'noindex, nofollow';
      const body = template(fs.readFileSync(full, 'utf8'), req);
      res.writeHead(200, headers); return res.end(req.method === 'HEAD' ? undefined : body);
    }
    headers['Cache-Control'] = 'public, max-age=300';
    res.writeHead(200, headers);
    return res.end(req.method === 'HEAD' ? undefined : fs.readFileSync(full));
  } catch (e) {
    if (res.headersSent) return;
    const status = e instanceof HttpError ? e.status : 500;
    if (status === 500) console.error(e);
    const isApi = pathname.startsWith('/api/');
    if (!isApi && status === 404) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(template(fs.readFileSync(path.join(PUBLIC_DIR, '404.html'), 'utf8'), req));
    }
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...(status === 413 ? { Connection: 'close' } : {}) });
    res.end(JSON.stringify({ error: status === 500 ? 'Something went wrong on our side' : e.message }));
  }
}

module.exports = { handler, markPaid };
