'use strict';
const fs = require('node:fs');
const path = require('node:path');
// Optional .env loader (no dependency): KEY=VALUE lines, existing environment wins.
try {
  for (const line of fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8').split('\n')) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#') && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch { /* no .env */ }

const http = require('node:http');
const { firstRun } = require('./db');
const { handler } = require('./app');

const creds = firstRun();
if (creds.length) {
  console.log('\n=== First run: accounts created (shown once, store them safely) ===');
  creds.forEach((c) => console.log('  ' + c));
  console.log('===================================================================\n');
}
const port = Number(process.env.PORT) || 3000;
const server = http.createServer(handler);
server.requestTimeout = 30000;
server.headersTimeout = 15000;
server.listen(port, () => console.log(`Listening on http://localhost:${port}`));
process.on('SIGTERM', () => server.close(() => process.exit(0)));
