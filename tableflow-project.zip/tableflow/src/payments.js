'use strict';
const crypto = require('node:crypto');
const { HttpError } = require('./util');

const provider = () => (process.env.PAYMENT_PROVIDER || 'none').toLowerCase();
const isProd = () => process.env.NODE_ENV === 'production';

function onlineEnabled() {
  const p = provider();
  if (p === 'mock') return !isProd();
  if (p === 'stripe') return !!process.env.STRIPE_SECRET_KEY && !!process.env.STRIPE_WEBHOOK_SECRET;
  return false;
}
function status() {
  return {
    provider: provider(), online_enabled: onlineEnabled(),
    mock_blocked_in_production: provider() === 'mock' && isProd(),
    stripe_configured: !!process.env.STRIPE_SECRET_KEY, stripe_webhook_configured: !!process.env.STRIPE_WEBHOOK_SECRET,
    email_configured: !!process.env.RESEND_API_KEY && !!process.env.MAIL_FROM,
  };
}

// Returns { paidNow, ref } for mock, or { url, ref } for Stripe Checkout (Apple Pay / Google Pay appear automatically there).
async function startOnline({ paymentId, amount, currency, label, base, token, email }) {
  const p = provider();
  if (!onlineEnabled()) throw new HttpError(400, 'Online payment is not available. Please pay with cash or bank transfer.');
  if (p === 'mock') return { paidNow: true, ref: 'mock_' + crypto.randomBytes(6).toString('hex') };
  const form = new URLSearchParams();
  form.set('mode', 'payment');
  form.set('line_items[0][quantity]', '1');
  form.set('line_items[0][price_data][currency]', currency.toLowerCase());
  form.set('line_items[0][price_data][unit_amount]', String(amount));
  form.set('line_items[0][price_data][product_data][name]', label.slice(0, 120));
  form.set('metadata[payment_id]', String(paymentId));
  form.set('success_url', `${base}/t/${token}?paid=1`);
  form.set('cancel_url', `${base}/t/${token}?cancelled=1`);
  if (email) form.set('customer_email', email);
  const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, 'Content-Type': 'application/x-www-form-urlencoded', 'Idempotency-Key': `pay-${paymentId}` },
    body: form,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.url) { console.error('Stripe error', data?.error?.message); throw new HttpError(502, 'The payment provider is unavailable right now. Please try again or pay the waiter.'); }
  return { url: data.url, ref: data.id };
}

function verifyStripeWebhook(raw, header) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) throw new HttpError(400, 'Webhook not configured');
  const parts = Object.fromEntries(String(header || '').split(',').map((x) => x.split('=')));
  const t = Number(parts.t);
  if (!t || !parts.v1 || Math.abs(Date.now() / 1000 - t) > 300) throw new HttpError(400, 'Bad signature');
  const expected = crypto.createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(parts.v1);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new HttpError(400, 'Bad signature');
  try { return JSON.parse(raw); } catch { throw new HttpError(400, 'Bad payload'); }
}

async function sendMail(db, outboxId) {
  const row = db.prepare('SELECT * FROM outbox WHERE id=?').get(outboxId);
  if (!row) return;
  if (!process.env.RESEND_API_KEY || !process.env.MAIL_FROM) return; // stays "queued": receipt is still available online
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM, to: [row.to_addr], subject: row.subject, html: row.body_html }),
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    db.prepare(`UPDATE outbox SET status='sent' WHERE id=?`).run(outboxId);
  } catch (e) {
    db.prepare(`UPDATE outbox SET status='failed', error=? WHERE id=?`).run(String(e.message).slice(0, 200), outboxId);
  }
}

module.exports = { onlineEnabled, status, startOnline, verifyStripeWebhook, sendMail };
