'use strict';
// Answers stay on the server; the client only ever receives question + options.
const QUIZ = [
  { q: 'Which spice gives saffron-free biryani its golden colour?', options: ['Turmeric', 'Cumin', 'Black pepper', 'Cardamom'], answer: 0 },
  { q: 'Paneer is made by curdling which ingredient?', options: ['Soy milk', 'Milk', 'Coconut milk', 'Cream'], answer: 1 },
  { q: 'Which country is the origin of sushi?', options: ['China', 'Korea', 'Japan', 'Thailand'], answer: 2 },
  { q: 'What is the main ingredient of guacamole?', options: ['Avocado', 'Tomato', 'Peas', 'Cucumber'], answer: 0 },
  { q: 'Which of these is a type of Italian pasta?', options: ['Paella', 'Penne', 'Pierogi', 'Pho'], answer: 1 },
  { q: 'Naan is traditionally baked in a…', options: ['Tandoor', 'Wok', 'Steamer', 'Pressure cooker'], answer: 0 },
  { q: 'Which fruit is the base of a classic Lassi in India’s summer?', options: ['Mango', 'Kiwi', 'Pear', 'Plum'], answer: 0 },
  { q: 'Wasabi is most closely related to…', options: ['Horseradish', 'Chilli', 'Ginger', 'Garlic'], answer: 0 },
  { q: 'How many sides does a classic samosa have?', options: ['Two', 'Three', 'Four', 'Five'], answer: 1 },
  { q: 'Which grain is used to make traditional risotto?', options: ['Basmati', 'Arborio', 'Jasmine', 'Wild rice'], answer: 1 },
  { q: 'Gulab jamun is soaked in…', options: ['Honey', 'Sugar syrup', 'Milk', 'Jaggery water only'], answer: 1 },
  { q: 'Which herb is the main flavour of pesto?', options: ['Mint', 'Coriander', 'Basil', 'Thyme'], answer: 2 },
];
module.exports = { QUIZ };
