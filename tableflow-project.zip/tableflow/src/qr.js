'use strict';
// Minimal QR Code generator (byte mode, error correction level M, versions 1-6 => up to 106 bytes).
// Enough for table URLs such as https://example.com/t/<32 hex chars>.

const ECC_PER_BLOCK = [10, 16, 26, 18, 24, 16];
const NUM_BLOCKS = [1, 1, 1, 2, 2, 4];
const TOTAL_CW = [26, 44, 70, 100, 134, 172];
const ALIGN = [null, 18, 22, 26, 30, 34]; // second alignment coordinate; first is always 6

const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
})();
const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);

function generator(deg) {
  let g = [1];
  for (let i = 0; i < deg; i++) {
    const n = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) { n[j] ^= g[j]; n[j + 1] ^= mul(g[j], EXP[i]); }
    g = n;
  }
  return g;
}
function remainder(data, gen) {
  const deg = gen.length - 1;
  const res = new Array(deg).fill(0);
  for (const b of data) {
    const f = b ^ res.shift();
    res.push(0);
    if (f) for (let i = 0; i < deg; i++) res[i] ^= mul(gen[i + 1], f);
  }
  return res;
}

function buildCodewords(bytes) {
  let v = 0;
  for (; v < 6; v++) {
    const dataCw = TOTAL_CW[v] - ECC_PER_BLOCK[v] * NUM_BLOCKS[v];
    if (12 + 8 * bytes.length <= dataCw * 8) break;
  }
  if (v === 6) throw new Error('QR data too long');
  const dataCw = TOTAL_CW[v] - ECC_PER_BLOCK[v] * NUM_BLOCKS[v];
  const bits = [];
  const push = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
  push(0b0100, 4); push(bytes.length, 8);
  for (const b of bytes) push(b, 8);
  push(0, Math.min(4, dataCw * 8 - bits.length));
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xec; data.length < dataCw; pad ^= 0xec ^ 0x11) data.push(pad);

  const nb = NUM_BLOCKS[v], eccLen = ECC_PER_BLOCK[v];
  const shortLen = Math.floor(dataCw / nb), numLong = dataCw % nb;
  const gen = generator(eccLen);
  const blocks = [], eccs = [];
  for (let i = 0, k = 0; i < nb; i++) {
    const len = shortLen + (i < nb - numLong ? 0 : 1);
    const d = data.slice(k, k + len); k += len;
    blocks.push(d); eccs.push(remainder(d, gen));
  }
  const out = [];
  for (let i = 0; i <= shortLen; i++) for (const b of blocks) if (i < b.length) out.push(b[i]);
  for (let i = 0; i < eccLen; i++) for (const e of eccs) out.push(e[i]);
  return { version: v + 1, codewords: out };
}

function makeMatrix(version, codewords) {
  const size = version * 4 + 17;
  const mod = Array.from({ length: size }, () => new Array(size).fill(false));
  const fn = Array.from({ length: size }, () => new Array(size).fill(false));
  const setFn = (x, y, dark) => { mod[y][x] = dark; fn[y][x] = true; };

  for (let i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
  const finder = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx, y = cy + dy;
      if (x < 0 || y < 0 || x >= size || y >= size) continue;
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      setFn(x, y, d !== 2 && d !== 4);
    }
  };
  finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
  if (version >= 2) {
    const c = ALIGN[version - 1];
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setFn(c + dx, c + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
  }
  const formatBits = (mask) => {
    const data = (0 << 3) | mask; // ECC level M = 00
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    const bits = ((data << 10) | rem) ^ 0x5412;
    const bit = (i) => ((bits >>> i) & 1) !== 0;
    for (let i = 0; i <= 5; i++) setFn(8, i, bit(i));
    setFn(8, 7, bit(6)); setFn(8, 8, bit(7)); setFn(7, 8, bit(8));
    for (let i = 9; i < 15; i++) setFn(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) setFn(size - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) setFn(8, size - 15 + i, bit(i));
    setFn(8, size - 8, true);
  };
  formatBits(0); // reserve format areas

  let i = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
      const x = right - j;
      const y = ((right + 1) & 2) === 0 ? size - 1 - vert : vert;
      if (!fn[y][x] && i < codewords.length * 8) {
        mod[y][x] = ((codewords[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0;
        i++;
      }
    }
  }

  const MASKS = [
    (x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
    (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0,
  ];
  const applyMask = (m) => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && MASKS[m](x, y)) mod[y][x] = !mod[y][x]; };
  const penalty = () => {
    let p = 0;
    const line = (get) => {
      for (let a = 0; a < size; a++) {
        let run = 1;
        for (let b = 1; b < size; b++) {
          if (get(a, b) === get(a, b - 1)) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1;
        }
      }
    };
    line((a, b) => mod[a][b]); line((a, b) => mod[b][a]);
    for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) {
      const c = mod[y][x];
      if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3;
    }
    // N3: finder-like 1:1:3:1:1 patterns with a 4-module light border (+40 each), rows and columns
    const PA = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], PB = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    for (let a = 0; a < size; a++) for (let b = 0; b + 11 <= size; b++) {
      for (const pat of [PA, PB]) {
        let r = true, c = true;
        for (let k = 0; k < 11 && (r || c); k++) { if ((mod[a][b + k] ? 1 : 0) !== pat[k]) r = false; if ((mod[b + k][a] ? 1 : 0) !== pat[k]) c = false; }
        if (r) p += 40; if (c) p += 40;
      }
    }
    let dark = 0;
    for (const row of mod) for (const c of row) if (c) dark++;
    p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
    return p;
  };
  let best = 0, bestP = Infinity;
  for (let m = 0; m < 8; m++) {
    applyMask(m); formatBits(m);
    const p = penalty();
    if (p < bestP) { bestP = p; best = m; }
    applyMask(m); // undo
  }
  applyMask(best); formatBits(best);
  mod.mask = best;
  return mod;
}

function qrMatrix(text) {
  const bytes = [...Buffer.from(text, 'utf8')];
  const { version, codewords } = buildCodewords(bytes);
  return makeMatrix(version, codewords);
}

function qrSvg(text, { border = 4, dark = '#111111', light = '#ffffff' } = {}) {
  const m = qrMatrix(text);
  const n = m.length + border * 2;
  let d = '';
  for (let y = 0; y < m.length; y++) for (let x = 0; x < m.length; x++) if (m[y][x]) d += `M${x + border},${y + border}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="${light}"/><path d="${d}" fill="${dark}"/></svg>`;
}

module.exports = { qrMatrix, qrSvg };
