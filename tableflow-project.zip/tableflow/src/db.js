'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { hashPassword, token } = require('./util');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'app.db');
if (DB_PATH !== ':memory:') fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, pass_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('admin','waiter','kitchen')), active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS dining_tables(
  id INTEGER PRIMARY KEY, label TEXT UNIQUE NOT NULL, token TEXT UNIQUE NOT NULL, seats INTEGER NOT NULL DEFAULT 4,
  x REAL NOT NULL DEFAULT 10, y REAL NOT NULL DEFAULT 10, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, name TEXT NOT NULL, sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS items(
  id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', price_cents INTEGER NOT NULL,
  diet TEXT NOT NULL DEFAULT 'veg', spice INTEGER NOT NULL DEFAULT 0, sizes TEXT NOT NULL DEFAULT '[]',
  allergens TEXT NOT NULL DEFAULT '[]', station TEXT NOT NULL DEFAULT 'kitchen', prep_minutes INTEGER NOT NULL DEFAULT 10,
  available INTEGER NOT NULL DEFAULT 1, emoji TEXT NOT NULL DEFAULT '🍽️', sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS deals(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  item_id INTEGER REFERENCES items(id) ON DELETE SET NULL, deal_price_cents INTEGER, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS guests(
  id TEXT PRIMARY KEY, nickname TEXT NOT NULL, points INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY, table_id INTEGER NOT NULL REFERENCES dining_tables(id), guest_id TEXT,
  status TEXT NOT NULL CHECK(status IN('placed','sent','cancelled')), note TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL, sent_at INTEGER, closed_at INTEGER);
CREATE TABLE IF NOT EXISTS order_items(
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE, item_id INTEGER,
  name TEXT NOT NULL, size TEXT NOT NULL DEFAULT '', qty INTEGER NOT NULL, unit_price_cents INTEGER NOT NULL,
  notes TEXT NOT NULL DEFAULT '', station TEXT NOT NULL, prep_minutes INTEGER NOT NULL DEFAULT 10,
  status TEXT NOT NULL DEFAULT 'new' CHECK(status IN('new','preparing','ready','served','cancelled')),
  started_at INTEGER, ready_at INTEGER, paid_payment_id INTEGER);
CREATE TABLE IF NOT EXISTS calls(
  id INTEGER PRIMARY KEY, table_id INTEGER NOT NULL REFERENCES dining_tables(id), kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','ack','done')), created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, table_id INTEGER NOT NULL REFERENCES dining_tables(id), guest_id TEXT,
  amount_cents INTEGER NOT NULL, tip_cents INTEGER NOT NULL DEFAULT 0, method TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN('processing','awaiting_staff','paid','failed','cancelled')),
  provider_ref TEXT, email TEXT, receipt_token TEXT UNIQUE NOT NULL, created_at INTEGER NOT NULL, paid_at INTEGER, closed_at INTEGER);
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY, table_id INTEGER NOT NULL, rating INTEGER NOT NULL, comment TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS rewards(id INTEGER PRIMARY KEY, name TEXT NOT NULL, cost_points INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS redemptions(
  id INTEGER PRIMARY KEY, guest_id TEXT NOT NULL, reward_id INTEGER NOT NULL, reward_name TEXT NOT NULL, table_id INTEGER NOT NULL,
  code TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS points_ledger(
  id INTEGER PRIMARY KEY, guest_id TEXT NOT NULL, delta INTEGER NOT NULL, reason TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS games(
  id INTEGER PRIMARY KEY, p1 TEXT NOT NULL, p2 TEXT, p1_nick TEXT NOT NULL, p2_nick TEXT, p1_table TEXT NOT NULL, p2_table TEXT,
  board TEXT NOT NULL DEFAULT '---------', turn TEXT NOT NULL DEFAULT 'X',
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','playing','won','draw','abandoned')), winner TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS quiz_answers(
  guest_id TEXT NOT NULL, qid INTEGER NOT NULL, correct INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(guest_id, qid));
CREATE TABLE IF NOT EXISTS leads(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, restaurant TEXT NOT NULL DEFAULT '', message TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY, to_addr TEXT NOT NULL, subject TEXT NOT NULL, body_html TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued', error TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_orders_table ON orders(table_id, closed_at);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_pay_table ON payments(table_id, closed_at);
CREATE INDEX IF NOT EXISTS idx_calls_table ON calls(table_id, status);
`);

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}

const DEFAULT_SETTINGS = {
  restaurant_name: 'My Restaurant',
  currency: 'INR',
  locale: 'en-IN',
  tax_percent: '5',
  tip_presets: '0,5,10,15',
  wifi_ssid: '',
  wifi_password: '',
  review_url: '',
  base_url: '',
  points_per_unit: '1',
};
const getSettings = () => {
  const out = { ...DEFAULT_SETTINGS };
  for (const r of db.prepare('SELECT key,value FROM settings').all()) out[r.key] = r.value;
  return out;
};
const setSetting = (k, v) => db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v));

function firstRun() {
  const out = [];
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c === 0) {
    const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
    const pw = process.env.ADMIN_PASSWORD || token(9);
    db.prepare('INSERT INTO users(email,name,pass_hash,role,created_at) VALUES(?,?,?,?,?)').run(email, 'Owner', hashPassword(pw), 'admin', Date.now());
    out.push(`admin   ${email}  password: ${pw}`);
    if (process.env.DEMO_MODE === '1') {
      for (const [role, name] of [['waiter', 'Demo Waiter'], ['kitchen', 'Demo Kitchen']]) {
        const p = token(9);
        db.prepare('INSERT INTO users(email,name,pass_hash,role,created_at) VALUES(?,?,?,?,?)').run(`${role}@example.com`, name, hashPassword(p), role, Date.now());
        out.push(`${role.padEnd(7)} ${role}@example.com  password: ${p}`);
      }
    }
  }
  if (process.env.DEMO_MODE === '1' && db.prepare('SELECT COUNT(*) c FROM categories').get().c === 0) seedDemo();
  return out;
}

function seedDemo() {
  setSetting('restaurant_name', 'Spice Route Kitchen');
  setSetting('wifi_ssid', 'SpiceRoute-Guest');
  setSetting('wifi_password', 'welcome2spice');
  const cat = db.prepare('INSERT INTO categories(name,sort) VALUES(?,?)');
  const item = db.prepare(`INSERT INTO items(category_id,name,description,price_cents,diet,spice,sizes,allergens,station,prep_minutes,emoji,sort)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`);
  const J = JSON.stringify;
  const half = J([{ name: 'Half', delta_cents: -6000 }, { name: 'Full', delta_cents: 0 }]);
  const c = {};
  ['Starters', 'Mains', 'Breads & Rice', 'Drinks', 'Desserts'].forEach((n, i) => { c[n] = Number(cat.run(n, i).lastInsertRowid); });
  const rows = [
    [c.Starters, 'Paneer Tikka', 'Charred cottage cheese marinated in yoghurt and spices', 26900, 'veg', 2, '[]', ['dairy'], 'grill', 12, '🧀'],
    [c.Starters, 'Tandoori Chicken', 'Clay-oven chicken, smoky and juicy', 32900, 'nonveg', 2, half, ['dairy'], 'grill', 18, '🍗'],
    [c.Starters, 'Veg Spring Rolls', 'Crisp rolls with sweet chilli dip', 17900, 'veg', 1, '[]', ['gluten', 'soy'], 'kitchen', 8, '🥟'],
    [c.Starters, 'Masala Fries', 'Skin-on fries tossed in chaat masala', 14900, 'vegan', 1, '[]', [], 'kitchen', 7, '🍟'],
    [c.Mains, 'Butter Chicken', 'Tandoori chicken in a creamy tomato gravy', 36900, 'nonveg', 1, half, ['dairy', 'nuts'], 'kitchen', 15, '🍛'],
    [c.Mains, 'Dal Makhani', 'Slow-cooked black lentils with butter and cream', 27900, 'veg', 0, half, ['dairy'], 'kitchen', 12, '🥣'],
    [c.Mains, 'Hakka Noodles', 'Wok-tossed noodles with crunchy vegetables', 22900, 'vegan', 1, '[]', ['gluten', 'soy'], 'kitchen', 10, '🍜'],
    [c.Mains, 'Veg Biryani', 'Fragrant basmati rice layered with vegetables, served with raita', 28900, 'veg', 2, '[]', ['dairy'], 'kitchen', 20, '🍚'],
    [c['Breads & Rice'], 'Garlic Naan', 'Tandoor-baked bread brushed with garlic butter', 6900, 'veg', 0, '[]', ['gluten', 'dairy'], 'grill', 6, '🫓'],
    [c['Breads & Rice'], 'Steamed Rice', 'Plain basmati rice', 9900, 'vegan', 0, '[]', [], 'kitchen', 5, '🍚'],
    [c.Drinks, 'Mango Lassi', 'Chilled yoghurt and Alphonso mango', 12900, 'veg', 0, '[]', ['dairy'], 'bar', 4, '🥭'],
    [c.Drinks, 'Masala Chai', 'Spiced milk tea', 7900, 'veg', 0, '[]', ['dairy'], 'bar', 5, '🍵'],
    [c.Drinks, 'Fresh Lime Soda', 'Sweet, salted or mixed', 8900, 'vegan', 0, '[]', [], 'bar', 3, '🍋'],
    [c.Desserts, 'Gulab Jamun', 'Two warm milk dumplings in saffron syrup', 11900, 'veg', 0, '[]', ['dairy', 'gluten', 'nuts'], 'dessert', 5, '🍮'],
    [c.Desserts, 'Brownie with Ice Cream', 'Warm walnut brownie, vanilla ice cream', 17900, 'egg', 0, '[]', ['gluten', 'dairy', 'egg', 'nuts'], 'dessert', 6, '🍫'],
  ];
  const ids = rows.map((r, i) => Number(item.run(r[0], r[1], r[2], r[3], r[4], r[5], r[6], J(r[7]), r[8], r[9], r[10], i).lastInsertRowid));
  const deal = db.prepare('INSERT INTO deals(title,description,item_id,deal_price_cents) VALUES(?,?,?,?)');
  deal.run('Happy Hour: Mango Lassi', 'Special price on our best-selling drink', ids[10], 9900);
  deal.run('Dessert Duo', 'Order any two desserts and tell your waiter for a free scoop of ice cream', null, null);
  const table = db.prepare('INSERT INTO dining_tables(label,token,seats,x,y) VALUES(?,?,?,?,?)');
  for (let i = 0; i < 8; i++) table.run(`T${i + 1}`, token(16), i % 3 === 0 ? 2 : 4, 12 + (i % 4) * 22, 15 + Math.floor(i / 4) * 40);
  const rw = db.prepare('INSERT INTO rewards(name,cost_points) VALUES(?,?)');
  rw.run('Free soft drink', 60); rw.run('Free dessert', 120);
}

module.exports = { db, tx, getSettings, setSetting, firstRun, DEFAULT_SETTINGS };
