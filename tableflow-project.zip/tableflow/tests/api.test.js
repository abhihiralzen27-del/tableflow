'use strict';
process.env.DB_PATH = ':memory:';
process.env.DEMO_MODE = '1';
process.env.PAYMENT_PROVIDER = 'mock';
process.env.TRUST_PROXY = '1';
process.env.ADMIN_EMAIL = 'boss@test.local';
process.env.ADMIN_PASSWORD = 'Sup3rSecretPass';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { firstRun, db } = require('../src/db');
const { handler } = require('../src/app');

let base, server;
const creds = firstRun();
const pw = (role) => /password: (\w+)/.exec(creds.find((c) => c.startsWith(role)))[1];

class Client {
  constructor() { this.cookies = {}; this.ip = `10.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}`; }
  async req(method, path, body, headers = {}) {
    const h = { ...headers, 'x-forwarded-for': this.ip };
    const c = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
    if (c) h.cookie = c;
    if (body !== undefined) h['content-type'] = h['content-type'] || 'application/json';
    const r = await fetch(base + path, { method, headers: h, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    for (const sc of r.headers.getSetCookie()) { const [kv] = sc.split(';'); const i = kv.indexOf('='); const v = kv.slice(i + 1); if (v) this.cookies[kv.slice(0, i)] = v; else delete this.cookies[kv.slice(0, i)]; }
    const text = await r.text();
    let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
    return { status: r.status, json, text, headers: r.headers };
  }
  get(p) { return this.req('GET', p); }
  post(p, b = {}) { return this.req('POST', p, b); }
}
async function login(role) {
  const c = new Client();
  const email = role === 'admin' ? 'boss@test.local' : `${role}@example.com`;
  const r = await c.post('/api/auth/login', { email, password: role === 'admin' ? 'Sup3rSecretPass' : pw(role) });
  assert.equal(r.status, 200, r.text);
  return c;
}

test.before(async () => { server = http.createServer(handler); await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`; });
test.after(() => server.close());

const token = () => db.prepare('SELECT token FROM dining_tables ORDER BY id LIMIT 1').get().token;
const token2 = () => db.prepare('SELECT token FROM dining_tables ORDER BY id LIMIT 1 OFFSET 1').get().token;

test('security headers and static pages', async () => {
  const r = await new Client().get('/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal((await new Client().get('/robots.txt')).status, 200);
  assert.match((await new Client().get('/sitemap.xml')).text, /<urlset/);
});
test('path traversal and source files are not served', async () => {
  const c = new Client();
  for (const p of ['/../src/db.js', '/..%2fsrc%2fdb.js', '/%2e%2e/package.json', '/js/../../data/app.db', '/guest.html', '/src/db.js']) {
    const r = await c.get(p);
    assert.equal(r.status, 404, p);
  }
});
test('unauthenticated staff/admin endpoints are blocked', async () => {
  const c = new Client();
  for (const p of ['/api/staff/state', '/api/kitchen/state', '/api/admin/menu', '/api/admin/settings', '/api/admin/users', '/api/staff/stream']) assert.equal((await c.get(p)).status, 401, p);
  assert.equal((await c.post('/api/staff/orders/1/send')).status, 401);
});
test('role checks: kitchen cannot use admin or floor APIs', async () => {
  const k = await login('kitchen');
  assert.equal((await k.get('/api/admin/menu')).status, 403);
  assert.equal((await k.get('/api/staff/state')).status, 403);
  assert.equal((await k.get('/api/kitchen/state')).status, 200);
  const w = await login('waiter');
  assert.equal((await w.get('/api/admin/users')).status, 403);
});
test('login: wrong password rejected, brute force rate limited', async () => {
  const c = new Client();
  assert.equal((await c.post('/api/auth/login', { email: 'boss@test.local', password: 'nope' })).status, 401);
  let last;
  for (let i = 0; i < 12; i++) last = await c.post('/api/auth/login', { email: 'victim@test.local', password: 'bad' + i });
  assert.equal(last.status, 429);
});
test('session cookie flags', async () => {
  const r = await new Client().req('POST', '/api/auth/login', { email: 'waiter@example.com', password: pw('waiter') });
  const sc = r.headers.getSetCookie().join(';');
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/);
});
test('CSRF: cross-origin and non-JSON writes are rejected', async () => {
  const w = await login('waiter');
  const r1 = await w.req('POST', '/api/staff/tables/1/close', {}, { origin: 'https://evil.example' });
  assert.equal(r1.status, 403);
  const r2 = await w.req('POST', '/api/staff/tables/1/close', 'x=1', { 'content-type': 'text/plain' });
  assert.equal(r2.status, 415);
});
test('invalid table tokens give 404', async () => {
  const c = new Client();
  assert.equal((await c.get('/api/t/zzzz/menu')).status, 404);
  assert.equal((await c.get("/api/t/' OR 1=1 --/menu")).status, 404);
  assert.equal((await c.get('/api/t/' + 'a'.repeat(32) + '/menu')).status, 404);
});

test('guest menu includes allergens, spice, sizes and deal price', async () => {
  const g = new Client();
  const r = await g.get(`/api/t/${token()}/menu`);
  assert.equal(r.status, 200);
  const items = r.json.categories.flatMap((c) => c.items);
  assert.ok(items.length >= 10);
  assert.ok(items.some((i) => i.allergens.includes('nuts')));
  assert.ok(items.some((i) => i.sizes.length === 2));
  assert.ok(items.some((i) => i.deal_price_cents != null));
  assert.ok(g.cookies.gid);
  assert.ok(r.json.settings.methods.includes('card'));
});

let orderId, itemIds = [];
test('guest orders: server prices, validation, tampering', async () => {
  const g = new Client();
  const menu = (await g.get(`/api/t/${token()}/menu`)).json;
  const items = menu.categories.flatMap((c) => c.items);
  const paneer = items.find((i) => i.name === 'Paneer Tikka');
  const butter = items.find((i) => i.name === 'Butter Chicken');
  const lassi = items.find((i) => i.name === 'Mango Lassi');
  // client-sent price is ignored
  const r = await g.post(`/api/t/${token()}/orders`, { items: [{ id: paneer.id, qty: 2, price_cents: 1 }, { id: butter.id, qty: 1, size: 'Half' }, { id: lassi.id, qty: 1 }] });
  assert.equal(r.status, 200, r.text);
  orderId = r.json.order_id;
  const rows = db.prepare('SELECT * FROM order_items WHERE order_id=?').all(orderId);
  itemIds = rows.map((x) => x.id);
  assert.equal(rows.find((x) => x.name === 'Paneer Tikka').unit_price_cents, 26900);
  assert.equal(rows.find((x) => x.name === 'Butter Chicken').unit_price_cents, 30900);
  assert.equal(rows.find((x) => x.name === 'Mango Lassi').unit_price_cents, 9900);
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: [{ id: butter.id, qty: 1 }] })).status, 400); // size required
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: [{ id: paneer.id, qty: 0 }] })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: [{ id: paneer.id, qty: 9999 }] })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: [{ id: 99999, qty: 1 }] })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: 'x' })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/orders`, { items: [] })).status, 400);
});
test('XSS payload is stored as text and never echoed unescaped in receipts', async () => {
  const g = new Client();
  const menu = (await g.get(`/api/t/${token2()}/menu`)).json;
  const it = menu.categories[0].items[3];
  const r = await g.post(`/api/t/${token2()}/orders`, { items: [{ id: it.id, qty: 1, notes: '<script>alert(1)</script>' }], note: '<img src=x onerror=alert(1)>' });
  assert.equal(r.status, 200);
  assert.ok(db.prepare('SELECT notes FROM order_items WHERE order_id=?').get(r.json.order_id).notes.includes('<script>'));
});

test('unapproved orders are not billable; staff approval sends to kitchen', async () => {
  const g = new Client();
  let tab = (await g.get(`/api/t/${token()}/tab`)).json;
  assert.equal(tab.total, 0);
  assert.equal(tab.orders[0].status, 'placed');
  const k = await login('kitchen');
  assert.equal((await k.get('/api/kitchen/state')).json.orders.length, 0);
  const w = await login('waiter');
  const st = (await w.get('/api/staff/state')).json;
  assert.ok(st.orders.some((o) => o.id === orderId && o.status === 'placed'));
  assert.equal(st.tables.find((t) => t.label === 'T1').status, 'approve');
  assert.equal((await k.post(`/api/staff/orders/${orderId}/send`)).status, 403);
  assert.equal((await w.post(`/api/staff/orders/${orderId}/send`)).status, 200);
  assert.equal((await w.post(`/api/staff/orders/${orderId}/send`)).status, 400); // already sent
  tab = (await g.get(`/api/t/${token()}/tab`)).json;
  // subtotal 2*26900 + 30900 + 9900 = 94600, tax 5% = 4730
  assert.equal(tab.subtotal, 94600); assert.equal(tab.tax, 4730); assert.equal(tab.total, 99330);
  assert.equal((await k.get('/api/kitchen/state')).json.orders.length, 1);
});
test('kitchen workflow transitions are enforced', async () => {
  const k = await login('kitchen'), w = await login('waiter');
  const [a] = itemIds;
  assert.equal((await k.post('/api/staff/items/status', { ids: [a], status: 'served' })).status, 403);
  assert.equal((await k.post('/api/staff/items/status', { ids: [a], status: 'preparing' })).json.changed, 1);
  assert.ok(db.prepare('SELECT started_at FROM order_items WHERE id=?').get(a).started_at);
  assert.equal((await k.post('/api/staff/items/status', { ids: [a], status: 'ready' })).json.changed, 1);
  assert.equal((await w.post('/api/staff/items/status', { ids: [a], status: 'new' })).json.changed, 0); // ready -> new not allowed
  assert.equal((await w.post('/api/staff/items/status', { ids: itemIds, status: 'served' })).json.changed, 1); // only the ready one
  assert.equal((await k.post('/api/staff/items/status', { ids: ['x'], status: 'ready' })).status, 400);
});
test('waiter call: dedupe, visible on floor, acknowledged', async () => {
  const g = new Client(), w = await login('waiter');
  assert.equal((await g.post(`/api/t/${token()}/call`, { kind: 'waiter' })).status, 200);
  assert.equal((await g.post(`/api/t/${token()}/call`, { kind: 'waiter' })).json.already, true);
  assert.equal((await g.post(`/api/t/${token()}/call`, { kind: 'hack' })).status, 400);
  const st = (await w.get('/api/staff/state')).json;
  const call = st.calls.find((c) => c.table_label === 'T1' && c.kind === 'waiter');
  assert.ok(call);
  assert.equal(st.tables.find((t) => t.label === 'T1').status, 'help');
  assert.equal((await w.post(`/api/staff/calls/${call.id}`, { status: 'done' })).status, 200);
});

test('payments: validation, equal split, item split, tip, cash confirmation, receipt', async () => {
  const g = new Client();
  await g.get(`/api/t/${token()}/menu`);
  const tab = (await g.get(`/api/t/${token()}/tab`)).json;
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'bitcoin', mode: 'all' })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'cash', mode: 'equal', parts: 0 })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'cash', mode: 'items', item_ids: [999999] })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'cash', mode: 'all', tip_percent: 500 })).status, 400);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'card', mode: 'all', email: 'not-an-email' })).status, 400);
  // an item from another table cannot be paid here
  const otherItem = db.prepare('SELECT id FROM order_items WHERE order_id!=? LIMIT 1').get(orderId);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'cash', mode: 'items', item_ids: [otherItem.id] })).status, 400);
  // pay the Mango Lassi item by card with a 10% tip
  const lassi = db.prepare(`SELECT id,unit_price_cents FROM order_items WHERE order_id=? AND name='Mango Lassi'`).get(orderId);
  const p1 = await g.post(`/api/t/${token()}/pay`, { method: 'card', mode: 'items', item_ids: [lassi.id], tip_percent: 10, email: 'guest@example.com' });
  assert.equal(p1.status, 200, p1.text);
  assert.equal(p1.json.status, 'paid');
  assert.equal(p1.json.amount_cents, Math.round(9900 * 1.05));
  assert.equal(p1.json.tip_cents, Math.round(Math.round(9900 * 1.05) * 0.1));
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'card', mode: 'items', item_ids: [lassi.id] })).status, 400); // double pay
  const rcpt = await g.get('/r/' + p1.json.receipt);
  assert.equal(rcpt.status, 200); assert.match(rcpt.text, /Mango Lassi/); assert.match(rcpt.text, /noindex/);
  assert.equal((await g.get('/r/' + 'b'.repeat(32))).status, 404);
  assert.equal(db.prepare(`SELECT COUNT(*) c FROM outbox WHERE to_addr='guest@example.com'`).get().c, 1);
  // split the rest equally among 2 people: one by cash (needs staff), the other by Google Pay
  const t2 = (await g.get(`/api/t/${token()}/tab`)).json;
  assert.equal(t2.remaining, tab.total - p1.json.amount_cents);
  const share = Math.ceil(t2.remaining / 2);
  const p2 = await g.post(`/api/t/${token()}/pay`, { method: 'cash', mode: 'equal', parts: 2 });
  assert.equal(p2.json.status, 'awaiting_staff'); assert.equal(p2.json.amount_cents, share);
  const p3 = await g.post(`/api/t/${token()}/pay`, { method: 'google_pay', mode: 'equal', parts: 1 });
  assert.equal(p3.json.status, 'paid');
  const t3 = (await g.get(`/api/t/${token()}/tab`)).json;
  assert.equal(t3.remaining, 0);
  assert.equal((await g.post(`/api/t/${token()}/pay`, { method: 'card', mode: 'all' })).status, 400); // fully paid
  // table cannot be closed while a cash payment is unconfirmed? (money is committed, so closing is allowed only once paid up)
  const w = await login('waiter');
  const st = (await w.get('/api/staff/state')).json;
  const pend = st.pending_payments.find((p) => p.id === p2.json.payment_id);
  assert.ok(pend);
  assert.equal(st.tables.find((t) => t.label === 'T1').status, 'bill');
  assert.equal((await w.post(`/api/staff/payments/${pend.id}/confirm`)).status, 200);
  assert.equal((await w.post(`/api/staff/payments/${pend.id}/confirm`)).status, 400);
  assert.equal((await w.post('/api/staff/tables/1/close', {})).status, 200);
  assert.equal(db.prepare('SELECT COUNT(*) c FROM orders WHERE table_id=1 AND closed_at IS NULL').get().c, 0);
  const fresh = (await g.get(`/api/t/${token()}/tab`)).json;
  assert.equal(fresh.orders.length, 0);
  assert.ok((await g.get(`/api/t/${token()}/me`)).json.points > 0);
});
test('closing an unpaid table is refused for waiters', async () => {
  const w = await login('waiter'), g = new Client();
  const menu = (await g.get(`/api/t/${token2()}/menu`)).json;
  const o = db.prepare('SELECT id FROM orders WHERE table_id=2').get();
  await w.post(`/api/staff/orders/${o.id}/send`);
  assert.equal((await w.post('/api/staff/tables/2/close', { force: true })).status, 400);
  const a = await login('admin');
  assert.equal((await a.post('/api/staff/tables/2/close', { force: true })).status, 200);
});

test('rewards: redeem needs enough points, cannot go negative', async () => {
  const g = new Client();
  const menu = (await g.get(`/api/t/${token()}/menu`)).json;
  const expensive = menu.rewards.find((r) => r.cost_points === 120);
  const me = (await g.get(`/api/t/${token()}/me`)).json;
  if (me.points < 120) assert.equal((await g.post(`/api/t/${token()}/redeem`, { reward_id: expensive.id })).status, 400);
  db.prepare('UPDATE guests SET points=70 WHERE id=?').run(g.cookies.gid);
  const cheap = menu.rewards.find((r) => r.cost_points === 60);
  const r = await g.post(`/api/t/${token()}/redeem`, { reward_id: cheap.id });
  assert.equal(r.status, 200); assert.equal(r.json.points, 10); assert.match(r.json.code, /^[A-F0-9]{6}$/);
});
test('quiz: answers are never sent to the client, points are capped', async () => {
  const g = new Client();
  const q = await g.get(`/api/t/${token()}/quiz`);
  assert.equal(q.json.answer, undefined);
  const r = await g.post(`/api/t/${token()}/quiz`, { qid: q.json.qid, choice: 0 });
  assert.equal(r.status, 200);
  assert.equal((await g.post(`/api/t/${token()}/quiz`, { qid: q.json.qid, choice: 0 })).status, 400); // no replays
});
test('tic-tac-toe across two tables: turns, win, points', async () => {
  const a = new Client(), b = new Client();
  await a.get(`/api/t/${token()}/menu`); await b.get(`/api/t/${token2()}/menu`);
  const gid = (await a.post(`/api/t/${token()}/games`)).json.id;
  assert.equal((await a.post(`/api/t/${token()}/games`)).status, 400);
  assert.equal((await a.post(`/api/t/${token()}/games/${gid}/join`)).status, 400);
  assert.equal((await b.post(`/api/t/${token2()}/games/${gid}/join`)).status, 200);
  const lobby = (await a.get(`/api/t/${token()}/games`)).json;
  assert.equal(lobby.mine.mine, 'X'); assert.equal(lobby.mine.p2_table, 'T2');
  const mv = (c, t, cell) => c.post(`/api/t/${t}/games/${gid}/move`, { cell });
  assert.equal((await mv(b, token2(), 0)).status, 400); // not O's turn
  await mv(a, token(), 0); await mv(b, token2(), 3); await mv(a, token(), 1); await mv(b, token2(), 4);
  assert.equal((await mv(a, token(), 3)).status, 400); // occupied
  const last = await mv(a, token(), 2);
  assert.equal(last.json.status, 'won');
  assert.equal((await mv(b, token2(), 5)).status, 400);
  const intruder = new Client(); await intruder.get(`/api/t/${token()}/menu`);
  assert.equal((await mv(intruder, token(), 6)).status, 400);
  assert.equal((await a.get(`/api/t/${token()}/me`)).json.points >= 10, true);
});

test('admin: menu CRUD with validation, QR, users, settings', async () => {
  const a = await login('admin');
  const menu = (await a.get('/api/admin/menu')).json;
  const cat = menu.categories[0].id;
  const good = { category_id: cat, name: 'Test Dish', price_cents: 12345, diet: 'veg', station: 'kitchen', allergens: ['nuts'], sizes: [{ name: 'Big', delta_cents: 500 }] };
  const created = await a.post('/api/admin/items', good);
  assert.equal(created.status, 200);
  assert.equal((await a.post('/api/admin/items', { ...good, price_cents: -5 })).status, 400);
  assert.equal((await a.post('/api/admin/items', { ...good, allergens: ['unicorn'] })).status, 400);
  assert.equal((await a.post('/api/admin/items', { ...good, station: 'moon' })).status, 400);
  assert.equal((await a.req('PUT', `/api/admin/items/${created.json.id}`, { ...good, available: false })).status, 200);
  const menuG = (await new Client().get(`/api/t/${token()}/menu`)).json;
  assert.ok(!menuG.categories.flatMap((c) => c.items).some((i) => i.id === created.json.id)); // hidden when unavailable
  assert.equal((await a.req('DELETE', `/api/admin/items/${created.json.id}`)).status, 200);
  const qr = await a.get('/api/admin/tables/1/qr.svg');
  assert.equal(qr.status, 200); assert.match(qr.text, /^<svg/);
  assert.equal((await a.post('/api/admin/users', { email: 'x@y.com', name: 'X', role: 'waiter', password: 'short' })).status, 400);
  assert.equal((await a.post('/api/admin/users', { email: 'new@y.com', name: 'New', role: 'waiter', password: 'LongEnough123' })).status, 200);
  assert.equal((await a.post('/api/admin/users', { email: 'new@y.com', name: 'New', role: 'waiter', password: 'LongEnough123' })).status, 400);
  assert.equal((await a.req('PUT', '/api/admin/settings', { restaurant_name: 'R', currency: 'XXQ', tax_percent: 5, tip_presets: '0,5' })).status, 400);
  assert.equal((await a.req('PUT', '/api/admin/settings', { restaurant_name: 'R', currency: 'INR', tax_percent: 5, tip_presets: '0,5', review_url: 'javascript:alert(1)' })).status, 400);
  const ov = await a.get('/api/admin/overview');
  assert.equal(ov.status, 200); assert.ok(ov.json.sales.n >= 1);
});
test('rotating a table token invalidates the old QR', async () => {
  const a = await login('admin');
  const old = token2();
  assert.equal((await a.post('/api/admin/tables/2/rotate')).status, 200);
  assert.equal((await new Client().get(`/api/t/${old}/menu`)).status, 404);
  assert.equal((await new Client().get(`/api/t/${token2()}/menu`)).status, 200);
});
test('lead form validates and stores', async () => {
  const c = new Client();
  assert.equal((await c.post('/api/leads', { name: 'A', email: 'bad' })).status, 400);
  assert.equal((await c.post('/api/leads', { name: 'Asha', email: 'asha@cafe.in', restaurant: 'Cafe', message: 'Hi' })).status, 200);
});
test('oversized and malformed bodies', async () => {
  const c = new Client();
  assert.equal((await c.req('POST', '/api/leads', '{bad json')).status, 400);
  assert.equal((await c.req('POST', '/api/leads', JSON.stringify({ name: 'x'.repeat(100000) }))).status, 413);
});
test('stripe webhook rejects bad signatures', async () => {
  const r = await new Client().req('POST', '/api/webhooks/stripe', '{}', { 'stripe-signature': 't=1,v1=abc' });
  assert.ok([400].includes(r.status));
});
test('SSE stream requires auth for staff and works for guests', async () => {
  assert.equal((await new Client().get('/api/staff/stream')).status, 401);
  const ac = new AbortController();
  const r = await fetch(`${base}/api/t/${token()}/stream`, { signal: ac.signal });
  assert.equal(r.status, 200); assert.match(r.headers.get('content-type'), /event-stream/);
  ac.abort();
});
