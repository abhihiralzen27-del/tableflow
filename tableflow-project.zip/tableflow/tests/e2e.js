'use strict';
// Browser end-to-end test (Playwright). Usage: node tests/e2e.js <baseUrl> <waiterPw> <kitchenPw> <adminPw> <outDir>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const [base, wpw, kpw, apw, out] = process.argv.slice(2);
const fs = require('fs'); fs.mkdirSync(out, { recursive: true });
const errors = [];
const results = [];
const step = async (name, fn) => { try { await fn(); results.push(['PASS', name]); } catch (e) { results.push(['FAIL', name + ' :: ' + e.message.split('\n')[0]]); } };
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const mk = async (opts = {}) => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, ...opts });
    const page = await ctx.newPage();
    page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) errors.push(`[${m.type()}] ${page.url()} ${m.text()}`); });
    page.on('pageerror', (e) => errors.push('[pageerror] ' + e.message));
    page.on('requestfailed', (r) => errors.push('[requestfailed] ' + r.url()));
    return page;
  };
  // find the demo table link from landing
  const land = await mk({ viewport: { width: 1280, height: 900 } });
  await land.goto(base + '/');
  await land.screenshot({ path: out + '/landing-desktop.png', fullPage: true });
  const demo = await land.getAttribute('a.btn.primary', 'href');
  await step('landing: demo link points to a table', async () => { if (!/^\/t\/[a-f0-9]{32}$/.test(demo)) throw new Error(demo); });
  await step('landing: contact form works', async () => {
    await land.fill('#ln', 'Test Owner'); await land.fill('#le', 'owner@cafe.test'); await land.click('#lb');
    await land.waitForSelector('#lmsg:has-text("Thank you")', { timeout: 4000 });
  });
  const lm = await mk(); await lm.goto(base + '/'); await lm.screenshot({ path: out + '/landing-mobile.png', fullPage: true });
  await step('landing: no horizontal overflow on mobile', async () => { const w = await lm.evaluate(() => document.documentElement.scrollWidth); if (w > 392) throw new Error('scrollWidth ' + w); });

  // ---- guests at table 1 (two phones)
  const g1 = await mk({ permissions: ['clipboard-read', 'clipboard-write'] });
  await g1.goto(base + demo);
  await step('guest: menu renders with dishes', async () => { await g1.waitForSelector('.dish'); const n = await g1.locator('.dish').count(); if (n < 10) throw new Error('only ' + n); });
  await g1.screenshot({ path: out + '/guest-menu.png' });
  await step('guest: allergy filter hides dishes', async () => {
    const before = await g1.locator('.dish').count();
    await g1.click('summary'); await g1.click('button.chip:text-is("dairy")');
    const after = await g1.locator('.dish').count(); if (!(after < before)) throw new Error(`${before} -> ${after}`);
    await g1.click('button.chip:text-is("dairy")');
  });
  await step('guest: add sized dish to cart and order', async () => {
    await g1.click('.dish:has-text("Butter Chicken")');
    await g1.waitForSelector('.sheet'); await g1.screenshot({ path: out + '/guest-item.png' });
    await g1.fill('#dn', 'less spicy'); await g1.click('.sheet button.primary');
    await g1.click('.dish:has-text("Mango Lassi")'); await g1.click('.sheet button.primary');
    await g1.click('.navbtn:has-text("Cart")');
    await g1.waitForSelector('text=Your order'); await g1.screenshot({ path: out + '/guest-cart.png' });
    await g1.click('#place'); await g1.waitForSelector('text=Waiting for staff to confirm', { timeout: 5000 });
  });
  await step('guest: order text shown as text (XSS-safe note)', async () => {
    await g1.click('.navbtn:has-text("Menu")'); await g1.click('.dish:has-text("Masala Fries")');
    await g1.fill('#dn', '<img src=x onerror=window.__x=1>'); await g1.click('.sheet button.primary');
    await g1.click('.navbtn:has-text("Cart")'); await g1.fill('#on', '<b>bold</b>'); await g1.click('#place');
    await g1.waitForSelector('.card:has-text("Waiting for staff to confirm") >> nth=1'); const x = await g1.evaluate(() => window.__x); if (x) throw new Error('XSS executed');
  });

  // ---- waiter approves
  const w = await mk({ viewport: { width: 1280, height: 800 } });
  await w.goto(base + '/login'); await w.fill('#email', 'waiter@example.com'); await w.fill('#pw', wpw); await w.click('#go');
  await w.waitForURL('**/floor');
  await step('waiter: sees orders waiting and approves', async () => {
    await w.waitForSelector('button:has-text("Send to kitchen")', { timeout: 6000 });
    await w.screenshot({ path: out + '/floor.png' });
    await w.click('button:has-text("Send to kitchen") >> nth=0'); await w.waitForTimeout(600);
    await w.click('button:has-text("Send to kitchen") >> nth=0');
    await w.waitForFunction(() => !document.body.innerText.includes('Send to kitchen'), null, { timeout: 5000 });
  });
  await step('guest: sees live status change without reload', async () => { await g1.click('.navbtn:has-text("My table")'); await g1.waitForSelector('text=Sent to kitchen', { timeout: 6000 }); await g1.waitForSelector('text=Order received'); });

  // ---- kitchen
  const k = await mk({ viewport: { width: 1280, height: 800 } });
  await k.goto(base + '/login'); await k.fill('#email', 'kitchen@example.com'); await k.fill('#pw', kpw); await k.click('#go'); await k.waitForURL('**/kitchen');
  await step('kitchen: ticket appears with timer; cook -> ready', async () => {
    await k.waitForSelector('.ticket', { timeout: 6000 }); await k.screenshot({ path: out + '/kitchen.png' });
    await k.click('.kitem:has-text("Mango Lassi")'); await k.waitForSelector('.kitem.preparing');
    await k.click('.kitem.preparing'); await k.waitForSelector('.kitem.ready');
  });
  await step('guest: gets "ready" update live', async () => { await g1.waitForSelector('.status.ready', { timeout: 7000 }); });
  await step('waiter: marks served from Ready to serve', async () => { await w.waitForSelector('text=Ready to serve'); await w.click('button:has-text("Served") >> nth=0'); });

  // ---- call waiter
  await step('guest: call waiter -> floor map table turns red', async () => {
    await g1.click('.fab'); await g1.click('button:has-text("Call waiter")'); await w.waitForSelector('.tbl.help', { timeout: 6000 });
    await w.screenshot({ path: out + '/floor-help.png' });
    await w.click('button:has-text("Done")'); await w.waitForSelector('.tbl.help', { state: 'detached', timeout: 6000 });
  });

  // ---- games across tables
  await step('games: two tables play tic-tac-toe', async () => {
    const tableTok = await w.evaluate(async () => 0);
    const g2 = await mk();
    const adminApi = await fetch(base + '/api/health'); void adminApi;
    // table 2 token via admin api
    const ctx = g2.context(); const login = await ctx.request.post(base + '/api/auth/login', { data: { email: 'admin@example.com', password: apw } });
    const tabs = await (await ctx.request.get(base + '/api/admin/tables')).json();
    const tok2 = tabs.tables[1].token;
    const ctx2 = await browser.newContext({ viewport: { width: 390, height: 800 } }); const p2 = await ctx2.newPage(); await p2.goto(base + '/t/' + tok2);
    await g1.click('.navbtn:has-text("Play")'); await g1.click('button:has-text("Start a new game")'); await g1.waitForSelector('text=Waiting for an opponent');
    await p2.click('.navbtn:has-text("Play")'); await p2.waitForSelector('button:has-text("Join")', { timeout: 6000 }); await p2.click('button:has-text("Join")');
    await g1.waitForSelector('text=Your turn', { timeout: 6000 });
    await g1.screenshot({ path: out + '/guest-game.png' });
    const cell = async (p, i) => { await p.click(`.ttt button >> nth=${i}`); };
    await cell(g1, 0); await p2.waitForSelector('text=Your turn'); await cell(p2, 3); await g1.waitForSelector('text=Your turn'); await cell(g1, 1);
    await p2.waitForSelector('text=Your turn'); await cell(p2, 4); await g1.waitForSelector('text=Your turn'); await cell(g1, 2);
    await g1.waitForSelector('text=You won', { timeout: 6000 }); await p2.waitForSelector('text=You lost', { timeout: 6000 });
  });

  // ---- pay: split with a tip, cash then card (mock)
  await step('guest: split bill, tip, pay cash (staff confirms) and card', async () => {
    await g1.click('.navbtn:has-text("My table")'); await g1.click('button:has-text("Pay / split bill")');
    await g1.waitForSelector('text=Pay your share'); await g1.screenshot({ path: out + '/guest-pay.png' });
    await g1.click('button.chip:text-is("Split equally")'); await g1.click('button.chip:text-is("10%")'); await g1.click('label:has-text("Cash")'); await g1.fill('#em', 'guest@example.com');
    await g1.click('#paybtn'); await g1.waitForSelector('text=waiting for staff', { timeout: 6000 });
    await w.waitForSelector('text=Payments to confirm'); await w.click('button:has-text("Received")'); await w.waitForTimeout(800);
    await g1.click('button:has-text("Pay / split bill")'); await g1.click('button.chip:text-is("Whole bill")'); await g1.click('label:has-text("Card")');
    await g1.click('#paybtn'); await g1.waitForSelector('text=Fully paid', { timeout: 7000 });
  });
  await step('guest: receipt page and review', async () => {
    await g1.waitForSelector('text=How was your visit?'); await g1.click('.stars button >> nth=4'); await g1.fill('#rc', 'Lovely!'); await g1.click('button:has-text("Send review")'); await g1.waitForSelector('text=Thanks for your feedback');
    const href = await g1.getAttribute('a:has-text("Receipt")', 'href'); const rp = await mk(); await rp.goto(base + href); await rp.waitForSelector('text=Total paid'); await rp.screenshot({ path: out + '/receipt.png' });
  });
  await step('waiter: clears the paid table', async () => { await w.waitForSelector('.tbl.paid', { timeout: 6000 }); await w.click('.tbl.paid'); await w.click('button:has-text("Close & clear table")'); await w.waitForSelector('.tbl.paid', { state: 'detached', timeout: 6000 }); });

  // ---- admin
  const a = await mk({ viewport: { width: 1280, height: 900 } });
  await a.goto(base + '/login'); await a.fill('#email', 'admin@example.com'); await a.fill('#pw', apw); await a.click('#go'); await a.waitForURL('**/admin');
  await step('admin: overview shows sales and review', async () => { await a.waitForSelector('text=Sales today'); await a.waitForSelector('text=Lovely!'); await a.screenshot({ path: out + '/admin-overview.png', fullPage: true }); });
  await step('admin: add a dish and it appears on guest menu', async () => {
    await a.click('.tab:has-text("Menu")'); await a.click('button:has-text("+ Add dish")'); await a.fill('#in', 'E2E Test Samosa'); await a.fill('#ip', '45.50'); await a.click('button.chip:text-is("gluten")'); await a.click('button:has-text("Save dish")');
    await a.waitForSelector('text=E2E Test Samosa'); await a.screenshot({ path: out + '/admin-menu.png' });
    await g1.reload(); await g1.waitForSelector('.dish:has-text("E2E Test Samosa")');
  });
  await step('admin: tables page shows decodable QR images', async () => {
    await a.click('.tab:has-text("Tables")'); await a.waitForSelector('.qrcard img'); await a.waitForTimeout(500);
    const ok = await a.evaluate(() => [...document.querySelectorAll('.qrcard img')].every((i) => i.complete && i.naturalWidth > 0)); if (!ok) throw new Error('QR failed to load');
    await a.screenshot({ path: out + '/admin-tables.png', fullPage: true });
  });
  await step('admin: settings page loads and saves', async () => { await a.click('.tab:has-text("Settings")'); await a.fill('#s6', 'NewWifi'); await a.click('button:has-text("Save settings")'); await a.waitForSelector('text=Settings saved'); });
  await step('admin: staff page loads', async () => { await a.click('.tab:has-text("Staff")'); await a.waitForSelector('text=Team accounts'); });
  await step('unauthorized: kitchen user bounced from admin', async () => { await k.goto(base + '/admin'); await k.waitForURL('**/kitchen', { timeout: 5000 }); });
  await step('404 page and invalid table link are friendly', async () => { const p = await mk(); await p.goto(base + '/nope'); await p.waitForSelector('text=Page not found'); await p.goto(base + '/t/' + 'c'.repeat(32)); await p.waitForSelector('text=not valid'); });

  await browser.close();
  console.log(results.map((r) => r.join(' ')).join('\n'));
  const filtered = errors.filter((e) => !/401|404|400|429|Failed to load resource/.test(e));
  console.log('\nCONSOLE ERRORS (excluding expected HTTP error responses):', filtered.length); filtered.slice(0, 15).forEach((e) => console.log(' ', e));
  errors.slice(0, 10).forEach((e) => console.log('   all:', e.slice(0, 200)));
  console.log('ALL logged console warnings/errors:', errors.length);
  process.exit(results.some((r) => r[0] === 'FAIL') ? 1 : 0);
})();
